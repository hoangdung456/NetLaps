﻿@echo off
chcp 65001 >nul
echo ========================================================
echo   DANG NANG CAP NETLAPS TUTOR LEN PHIEN BAN V2.5.6
echo ========================================================
echo.
echo [1/3] Dang dung tien trinh cu...
taskkill /F /IM NetLaps.Tutor.exe >nul 2>&1
timeout /t 1 /nobreak >nul

echo [2/3] Dang ghi de tep nhi phan moi...
if exist "C:\Program Files\NetLaps\Tutor" (
    copy /Y "%~dp0NetLaps.Tutor.exe" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.exe" >nul 2>&1
    copy /Y "%~dp0NetClass.Core.dll" "C:\Program Files\NetLaps\Tutor\NetClass.Core.dll" >nul 2>&1
    copy /Y "%~dp0NetLaps.Tutor.dll" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.dll" >nul 2>&1
    echo [3/3] Dang khoi dong lai NetLaps Tutor v2.5.6...
    start "" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.exe"
) else (
    copy /Y "%~dp0NetLaps.Tutor.exe" "%~dp0..\NetLaps.Tutor.exe" >nul 2>&1
    copy /Y "%~dp0NetClass.Core.dll" "%~dp0..\NetClass.Core.dll" >nul 2>&1
    copy /Y "%~dp0NetLaps.Tutor.dll" "%~dp0..\NetLaps.Tutor.dll" >nul 2>&1
    echo [3/3] Dang khoi dong lai NetLaps Tutor v2.5.6...
    start "" "%~dp0..\NetLaps.Tutor.exe"
)
echo.
echo [HOAN TAT] Ban da cap nhat thanh cong NetLaps Tutor v2.5.6!
pause
