﻿@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [NetLaps] Dang xin quyen Administrator de cap nhat...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/c \"""%~f0\"""' -Verb runAs"
    exit /b
)

echo [1/3] Dung tien trinh cu...
taskkill /F /IM NetLaps.Tutor.exe >nul 2>&1
timeout /t 1 /nobreak >nul

echo [2/3] Ghi de file moi v2.5.6...
if exist "C:\Program Files\NetLaps\Tutor" (
    copy /Y "%~dp0NetClass.Core.dll" "C:\Program Files\NetLaps\Tutor\NetClass.Core.dll" >nul
    copy /Y "%~dp0NetLaps.Tutor.dll" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.dll" >nul
    copy /Y "%~dp0NetLaps.Tutor.exe" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.exe" >nul
    copy /Y "%~dp0NetLaps.Tutor.deps.json" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.deps.json" >nul
    copy /Y "%~dp0NetLaps.Tutor.runtimeconfig.json" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.runtimeconfig.json" >nul
    echo [3/3] Khoi dong lai NetLaps Tutor v2.5.6...
    start "" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.exe"
) else (
    copy /Y "%~dp0NetClass.Core.dll" "%~dp0..\NetClass.Core.dll" >nul
    copy /Y "%~dp0NetLaps.Tutor.dll" "%~dp0..\NetLaps.Tutor.dll" >nul
    copy /Y "%~dp0NetLaps.Tutor.exe" "%~dp0..\NetLaps.Tutor.exe" >nul
    echo [3/3] Khoi dong lai NetLaps Tutor v2.5.6...
    start "" "%~dp0..\NetLaps.Tutor.exe"
)
