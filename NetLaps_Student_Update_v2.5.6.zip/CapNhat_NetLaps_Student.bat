﻿@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [NetLaps] Yeu cau quyen Administrator de cap nhat phan mem...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/c \"""%~f0\"""' -Verb runAs"
    exit /b
)

echo ========================================================
echo   DANG NANG CAP NETLAPS STUDENT LEN PHIEN BAN V2.5.6
echo ========================================================
echo.
echo [1/3] Dang dung tien trinh cu...
taskkill /F /IM NetLaps.Student.exe >nul 2>&1
timeout /t 2 /nobreak >nul

echo [2/3] Dang ghi de tep nhi phan moi...
if exist "C:\Program Files\NetLaps\Student" (
    copy /Y "%~dp0NetLaps.Student.exe" "C:\Program Files\NetLaps\Student\NetLaps.Student.exe" >nul
    if exist "%~dp0NetClass.Core.dll" copy /Y "%~dp0NetClass.Core.dll" "C:\Program Files\NetLaps\Student\NetClass.Core.dll" >nul
    if exist "%~dp0NetLaps.Student.dll" copy /Y "%~dp0NetLaps.Student.dll" "C:\Program Files\NetLaps\Student\NetLaps.Student.dll" >nul
    echo [3/3] Dang khoi dong lai NetLaps Student v2.5.6...
    start "" "C:\Program Files\NetLaps\Student\NetLaps.Student.exe"
) else (
    copy /Y "%~dp0NetLaps.Student.exe" "%~dp0..\NetLaps.Student.exe" >nul
    if exist "%~dp0NetClass.Core.dll" copy /Y "%~dp0NetClass.Core.dll" "%~dp0..\NetClass.Core.dll" >nul
    if exist "%~dp0NetLaps.Student.dll" copy /Y "%~dp0NetLaps.Student.dll" "%~dp0..\NetLaps.Student.dll" >nul
    echo [3/3] Dang khoi dong lai NetLaps Student v2.5.6...
    start "" "%~dp0..\NetLaps.Student.exe"
)
echo.
echo [HOAN TAT] Ban da cap nhat thanh cong NetLaps Student v2.5.6!
timeout /t 3
