﻿@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [NetLaps] Dang xin quyen Administrator de cap nhat...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/c \"""%~f0\"""' -Verb runAs"
    exit /b
)

echo [1/3] Dung tien trinh cu...
taskkill /F /IM NetLaps.Student.exe >nul 2>&1
timeout /t 1 /nobreak >nul

echo [2/3] Ghi de file moi v2.5.6...
if exist "C:\Program Files\NetLaps\Student" (
    copy /Y "%~dp0NetClass.Core.dll" "C:\Program Files\NetLaps\Student\NetClass.Core.dll" >nul
    copy /Y "%~dp0NetLaps.Student.dll" "C:\Program Files\NetLaps\Student\NetLaps.Student.dll" >nul
    copy /Y "%~dp0NetLaps.Student.exe" "C:\Program Files\NetLaps\Student\NetLaps.Student.exe" >nul
    copy /Y "%~dp0NetLaps.Student.deps.json" "C:\Program Files\NetLaps\Student\NetLaps.Student.deps.json" >nul
    copy /Y "%~dp0NetLaps.Student.runtimeconfig.json" "C:\Program Files\NetLaps\Student\NetLaps.Student.runtimeconfig.json" >nul
    echo [3/3] Khoi dong lai NetLaps Student v2.5.6...
    start "" "C:\Program Files\NetLaps\Student\NetLaps.Student.exe"
) else (
    copy /Y "%~dp0NetClass.Core.dll" "%~dp0..\NetClass.Core.dll" >nul
    copy /Y "%~dp0NetLaps.Student.dll" "%~dp0..\NetLaps.Student.dll" >nul
    copy /Y "%~dp0NetLaps.Student.exe" "%~dp0..\NetLaps.Student.exe" >nul
    echo [3/3] Khoi dong lai NetLaps Student v2.5.6...
    start "" "%~dp0..\NetLaps.Student.exe"
)
