#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Tutor Linux - Native Desktop Window GUI for Ubuntu Linux v2.5.6
Provides a 100% native GTK3 desktop application window for school computer lab teachers.
No external web browser, no tabs, no address bar, no 'localhost' exposed.
"""

import sys
import os
import time
import urllib.request
import subprocess

APP_URL = "http://127.0.0.1:8080/"
APP_TITLE = "NetLaps Tutor v2.5.6 — Quản Lý Phòng Máy Trường Học"
ICON_PATH = "/opt/netlaps-teacher/netlaps_teacher.png"

def ensure_backend_running():
    """Ensure the local NetLaps teacher hub & API engine is running."""
    # Check if HTTP port 8080 responds
    try:
        with urllib.request.urlopen(APP_URL, timeout=1.0) as resp:
            if resp.status == 200:
                return True
    except:
        pass

    # Start backend server in background if not running
    try:
        subprocess.Popen(
            ["/opt/netlaps-teacher/netlaps-teacher", "--no-browser"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
    except Exception as e:
        pass

    # Wait up to 5 seconds for backend to become ready
    for _ in range(25):
        time.sleep(0.2)
        try:
            with urllib.request.urlopen(APP_URL, timeout=0.8) as resp:
                if resp.status == 200:
                    return True
        except:
            pass
    return False

def launch_native_gtk_window():
    """Launch true native GTK3 desktop window embedding WebKit engine."""
    import gi
    gi.require_version('Gtk', '3.0')
    
    # Try WebKit2 version 4.1 (Ubuntu 22.04 / 24.04) or 4.0 (Ubuntu 20.04)
    has_webkit = False
    for ver in ['4.1', '4.0']:
        try:
            gi.require_version('WebKit2', ver)
            from gi.repository import WebKit2
            has_webkit = True
            break
        except (ValueError, ImportError):
            continue

    if not has_webkit:
        return False

    from gi.repository import Gtk, Gdk, Gio, GLib

    class NetLapsTeacherApp(Gtk.Window):
        def __init__(self):
            super().__init__(title=APP_TITLE)
            self.set_default_size(1440, 900)
            self.set_position(Gtk.WindowPosition.CENTER)
            self.maximize()

            # Set Application Icon
            if os.path.exists(ICON_PATH):
                try:
                    self.set_icon_from_file(ICON_PATH)
                except:
                    pass

            # Configure WebKit Settings
            settings = WebKit2.Settings()
            settings.set_enable_javascript(True)
            settings.set_enable_webgl(True)
            settings.set_enable_smooth_scrolling(True)
            settings.set_javascript_can_access_clipboard(True)
            settings.set_enable_developer_extras(False) # Hide inspector from students

            # Create WebView
            self.webview = WebKit2.WebView.new_with_settings(settings)
            self.webview.connect("context-menu", self.on_context_menu)
            self.webview.load_uri(APP_URL)

            # Container
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            box.pack_start(self.webview, True, True, 0)
            self.add(box)

            # Keybindings
            self.connect("key-press-event", self.on_key_press)
            self.connect("destroy", Gtk.main_quit)

            self.is_fullscreen = False

        def on_key_press(self, widget, event):
            # F11: Toggle Fullscreen
            if event.keyval == Gdk.KEY_F11:
                if self.is_fullscreen:
                    self.unfullscreen()
                    self.is_fullscreen = False
                else:
                    self.fullscreen()
                    self.is_fullscreen = True
                return True
            # F5: Refresh view
            elif event.keyval == Gdk.KEY_F5:
                self.webview.reload()
                return True
            return False

        def on_context_menu(self, webview, context_menu, event, hit_test_result):
            # Suppress default browser right-click inspect menu
            context_menu.remove_all()
            return True

    win = NetLapsTeacherApp()
    win.show_all()
    Gtk.main()
    return True

def fallback_app_mode():
    """Fallback: Launches standalone desktop app window without URL bar/tabs."""
    user_dir = os.path.expanduser("~/.config/netlaps-teacher-profile")
    os.makedirs(user_dir, exist_ok=True)

    app_args = [
        f"--app={APP_URL}",
        "--new-window",
        f"--user-data-dir={user_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-translate",
        "--class=netlaps-teacher",
        "--name=NetLaps_Tutor",
        "--window-size=1440,900",
        "--start-maximized"
    ]

    browsers = [
        "google-chrome",
        "google-chrome-stable",
        "chromium-browser",
        "chromium",
        "brave-browser",
        "microsoft-edge"
    ]

    for b in browsers:
        try:
            subprocess.run(["which", b], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            os.execvp(b, [b] + app_args)
        except (subprocess.CalledProcessError, FileNotFoundError):
            continue

    # Firefox kiosk fallback
    try:
        subprocess.run(["which", "firefox"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        os.execvp("firefox", ["firefox", "--kiosk", APP_URL])
    except:
        pass

    # Generic fallback
    os.execvp("xdg-open", ["xdg-open", APP_URL])

if __name__ == "__main__":
    ensure_backend_running()

    # Priority 1: Native GTK3 Desktop Window (No browser at all)
    try:
        if launch_native_gtk_window():
            sys.exit(0)
    except Exception as e:
        pass

    # Priority 2: Standalone Isolated App Window Mode
    fallback_app_mode()
