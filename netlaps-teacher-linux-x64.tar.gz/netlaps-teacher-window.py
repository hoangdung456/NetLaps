#!/usr/bin/env python3
import sys
import os
import time
import urllib.request
import subprocess
import shutil

# Prevent WebKit2GTK DMA-BUF / GPU compositing crashes on Ubuntu 22.04 / 24.04 & VMs
os.environ.setdefault("WEBKIT_DISABLE_DMABUF_RENDERER", "1")
os.environ.setdefault("WEBKIT_DISABLE_COMPOSITING_MODE", "1")

APP_URL = "http://127.0.0.1:8080/"
ICON_PATH = "/opt/netlaps-teacher/netlaps_teacher.png"


def wait_for_server(timeout_sec=12):
    start = time.time()
    while time.time() - start < timeout_sec:
        try:
            with urllib.request.urlopen(APP_URL + "api/state", timeout=1) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False


def ensure_backend_running():
    if wait_for_server(timeout_sec=1):
        return True
    bin_path = "/opt/netlaps-teacher/netlaps-teacher"
    if os.path.exists(bin_path):
        try:
            subprocess.Popen(
                [bin_path, "--no-browser"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except Exception:
            pass
    return wait_for_server(timeout_sec=10)


def fallback_app_mode():
    profile_dir = os.path.expanduser("~/.config/netlaps-teacher-app")
    browsers = [
        "google-chrome",
        "google-chrome-stable",
        "chromium",
        "chromium-browser",
        "microsoft-edge",
        "brave-browser",
    ]
    for b in browsers:
        if shutil.which(b):
            cmd = [
                b,
                f"--app={APP_URL}",
                f"--user-data-dir={profile_dir}",
                "--class=netlaps-teacher",
                "--new-window",
                "--start-maximized",
            ]
            if os.geteuid() == 0:
                cmd.append("--no-sandbox")
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            sys.exit(0)

    if shutil.which("firefox"):
        subprocess.Popen(
            ["firefox", "--new-window", APP_URL],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        sys.exit(0)

    if shutil.which("xdg-open"):
        subprocess.Popen(
            ["xdg-open", APP_URL],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        sys.exit(0)


def main():
    ensure_backend_running()

    try:
        import gi
        gi.require_version("Gtk", "3.0")
        try:
            gi.require_version("WebKit2", "4.1")
        except ValueError:
            gi.require_version("WebKit2", "4.0")
        from gi.repository import Gtk, WebKit2, GdkPixbuf, Gdk
    except Exception:
        fallback_app_mode()
        return

    ok, _ = Gtk.init_check(sys.argv)
    if not ok:
        fallback_app_mode()
        return

    win = Gtk.Window(title="NetLaps Tutor v2.7.0 — Quản Lý Phòng Máy Trường Học")
    win.set_wmclass("netlaps-teacher", "NetLaps Tutor")
    win.set_default_size(1366, 820)
    win.set_position(Gtk.WindowPosition.CENTER)
    win.maximize()

    if os.path.exists(ICON_PATH):
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file(ICON_PATH)
            win.set_icon(pixbuf)
        except Exception:
            pass

    webview = WebKit2.WebView()
    settings = webview.get_settings()
    settings.set_enable_javascript(True)
    settings.set_enable_developer_extras(False)
    settings.set_enable_write_console_messages_to_stdout(False)
    try:
        settings.set_hardware_acceleration_policy(WebKit2.HardwareAccelerationPolicy.NEVER)
    except Exception:
        pass

    # Set dark background to match NetLaps theme while loading
    try:
        rgba = Gdk.RGBA()
        rgba.parse("#050914")
        webview.set_background_color(rgba)
    except Exception:
        pass

    webview.load_uri(APP_URL)
    win.add(webview)
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    win.present()
    Gtk.main()


if __name__ == "__main__":
    main()
