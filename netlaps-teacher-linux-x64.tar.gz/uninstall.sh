#!/usr/bin/env bash
# NetLaps Teacher Linux Uninstaller v2.5.6
set -e

if [ "$EUID" -ne 0 ]; then
  echo "Vui lòng chạy với quyền sudo: sudo bash uninstall.sh"
  exit 1
fi

echo "Đang gỡ cài đặt Máy chủ Giáo viên NetLaps Teacher..."
systemctl stop netlaps-teacher.service 2>/dev/null || true
systemctl disable netlaps-teacher.service 2>/dev/null || true
rm -f /etc/systemd/system/netlaps-teacher.service
systemctl daemon-reload

rm -rf /opt/netlaps-teacher
rm -f /usr/share/applications/netlaps-teacher.desktop
rm -f /usr/share/pixmaps/netlaps_teacher.png
rm -f /usr/bin/netlaps-teacher /usr/bin/netlaps-teacher-gui

for user_home in /home/*; do
  rm -f "${user_home}/Desktop/netlaps-teacher.desktop" 2>/dev/null || true
  rm -rf "${user_home}/.config/netlaps-teacher-profile" 2>/dev/null || true
done

echo "✅ ĐÃ GỠ BỎ MÁY CHỦ GIÁO VIÊN NETLAPS HOÀN TOÀN KHỎI HỆ THỐNG!"
