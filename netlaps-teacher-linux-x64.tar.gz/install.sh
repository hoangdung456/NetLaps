#!/usr/bin/env bash
# ==============================================================================
# NETLAPS TUTOR FOR UBUNTU LINUX — UNIVERSAL INSTALLER v2.5.6
# Hỗ trợ: Ubuntu 20.04 / 22.04 / 24.04 LTS (x86_64 / amd64)
# Hotline / Zalo: 0385545556 | Facebook: fb.com/HdMarketing98
# ==============================================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   🛡️ ĐANG CÀI ĐẶT NETLAPS TUTOR (GIÁO VIÊN) TRÊN UBUNTU LINUX v2.5.6...      ${NC}"
echo -e "${BLUE}==============================================================================${NC}"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[LỖI] Vui lòng chạy với quyền quản trị viên: sudo bash install.sh${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/netlaps-teacher"

echo -e "${YELLOW}[1/4] Sao chép tệp chương trình máy chủ và launcher Desktop vào ${INSTALL_DIR}...${NC}"
mkdir -p "${INSTALL_DIR}"
cp -f "${SCRIPT_DIR}/netlaps-teacher" "${INSTALL_DIR}/netlaps-teacher"
cp -f "${SCRIPT_DIR}/netlaps-teacher-app" "${INSTALL_DIR}/netlaps-teacher-app" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps-teacher-window.py" "${INSTALL_DIR}/netlaps-teacher-window.py" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_teacher.png" "${INSTALL_DIR}/netlaps_teacher.png" 2>/dev/null || true

chmod 755 "${INSTALL_DIR}/netlaps-teacher"
chmod 755 "${INSTALL_DIR}/netlaps-teacher-app" 2>/dev/null || true
chmod 755 "${INSTALL_DIR}/netlaps-teacher-window.py" 2>/dev/null || true
ln -sf "${INSTALL_DIR}/netlaps-teacher-app" /usr/bin/netlaps-teacher-gui
ln -sf "${INSTALL_DIR}/netlaps-teacher" /usr/bin/netlaps-teacher

# Install icons
mkdir -p /usr/share/pixmaps
cp -f "${SCRIPT_DIR}/netlaps_teacher.png" /usr/share/pixmaps/netlaps_teacher.png 2>/dev/null || true

echo -e "${YELLOW}[2/4] Cài đặt Dịch vụ nền (Systemd Service)...${NC}"
if [ -f "${SCRIPT_DIR}/netlaps-teacher.service" ]; then
  cp -f "${SCRIPT_DIR}/netlaps-teacher.service" /etc/systemd/system/netlaps-teacher.service
  chmod 644 /etc/systemd/system/netlaps-teacher.service
  systemctl daemon-reload
  systemctl enable netlaps-teacher.service
fi

echo -e "${YELLOW}[3/4] Cài đặt Biểu tượng ứng dụng Desktop & Menu Dash...${NC}"
if [ -f "${SCRIPT_DIR}/netlaps-teacher.desktop" ]; then
  mkdir -p /usr/share/applications
  cp -f "${SCRIPT_DIR}/netlaps-teacher.desktop" /usr/share/applications/netlaps-teacher.desktop
  chmod 644 /usr/share/applications/netlaps-teacher.desktop

  # Place desktop icon on desktop of all active human users
  for user_home in /home/*; do
    if [ -d "${user_home}/Desktop" ]; then
      cp -f "${SCRIPT_DIR}/netlaps-teacher.desktop" "${user_home}/Desktop/netlaps-teacher.desktop"
      chmod +x "${user_home}/Desktop/netlaps-teacher.desktop"
      user_name=$(basename "${user_home}")
      chown "${user_name}:${user_name}" "${user_home}/Desktop/netlaps-teacher.desktop" 2>/dev/null || true
      su - "${user_name}" -c "gio set '${user_home}/Desktop/netlaps-teacher.desktop' metadata::trusted true" 2>/dev/null || true
    fi
  done
fi

echo -e "${YELLOW}[4/4] Khởi động Dịch vụ NetLaps Tutor v2.5.6...${NC}"
systemctl restart netlaps-teacher.service || true

LOCAL_IP=$(hostname -I | awk '{print $1}')
echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   ✅ CÀI ĐẶT THÀNH CÔNG NETLAPS TUTOR v2.5.6 TRÊN UBUNTU LINUX!              ${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo -e "🖥️ CÁCH SỬ DỤNG:"
echo -e "   1. Bấm đúp vào biểu tượng 'NetLaps Tutor' ngoài Desktop hoặc trong Menu Ứng dụng."
echo -e "   2. Hoặc chạy lệnh trong Terminal: netlaps-teacher-gui"
echo -e "   3. Bảng điều khiển từ xa từ thiết bị khác: http://${LOCAL_IP}:8080/"
echo -e ""
echo -e "📡 Cổng nhận máy học sinh (TCP Hub): ${LOCAL_IP}:5055"
echo -e "📁 Thư mục cài đặt:                   ${INSTALL_DIR}"
echo -e "${BLUE}==============================================================================${NC}"
