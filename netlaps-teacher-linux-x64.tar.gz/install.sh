#!/usr/bin/env bash
# ==============================================================================
# NETLAPS TUTOR FOR UBUNTU LINUX — UNIVERSAL INSTALLER v2.7.0
# Hỗ trợ: Ubuntu 20.04 / 22.04 / 24.04 LTS (x86_64 / amd64)
# Hotline / Zalo: 0385545556 | Facebook: fb.com/HdMarketing98
# ==============================================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   🛡️ ĐANG CÀI ĐẶT NETLAPS TUTOR (GIÁO VIÊN) TRÊN UBUNTU LINUX v2.7.0...      ${NC}"
echo -e "${BLUE}==============================================================================${NC}"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[LỖI] Vui lòng chạy với quyền quản trị viên: sudo bash install.sh${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/netlaps-teacher"

if command -v apt-get >/dev/null 2>&1; then
  echo -e "${YELLOW}[0/4] Kiểm tra thư viện giao diện (python3-gi, gir1.2-gtk-3.0, webkit2)...${NC}"
  apt-get update -qq 2>/dev/null || true
  apt-get install -y -qq python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1 2>/dev/null || \
  apt-get install -y -qq python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.0 2>/dev/null || true
fi

echo -e "${YELLOW}[1/4] Sao chép tệp chương trình máy chủ và launcher Desktop vào ${INSTALL_DIR}...${NC}"
mkdir -p "${INSTALL_DIR}"
cp -f "${SCRIPT_DIR}/netlaps-teacher" "${INSTALL_DIR}/netlaps-teacher"
cp -f "${SCRIPT_DIR}/netlaps-teacher-app" "${INSTALL_DIR}/netlaps-teacher-app" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps-teacher-window.py" "${INSTALL_DIR}/netlaps-teacher-window.py" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_teacher.png" "${INSTALL_DIR}/netlaps_teacher.png" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps-teacher.desktop" "${INSTALL_DIR}/netlaps-teacher.desktop" 2>/dev/null || true

chmod 755 "${INSTALL_DIR}/netlaps-teacher"
chmod 755 "${INSTALL_DIR}/netlaps-teacher-app" 2>/dev/null || true
chmod 755 "${INSTALL_DIR}/netlaps-teacher-window.py" 2>/dev/null || true
ln -sf "${INSTALL_DIR}/netlaps-teacher-app" /usr/bin/netlaps-teacher-gui
ln -sf "${INSTALL_DIR}/netlaps-teacher" /usr/bin/netlaps-teacher

# Mở cổng tường lửa Ubuntu (ufw)
if command -v ufw >/dev/null 2>&1; then
  ufw allow 5055/tcp >/dev/null 2>&1 || true
  ufw allow 5056/udp >/dev/null 2>&1 || true
  ufw allow 8080/tcp >/dev/null 2>&1 || true
fi

# Cài đặt Icons vào pixmaps và icon theme
mkdir -p /usr/share/pixmaps
mkdir -p /usr/share/icons/hicolor/128x128/apps
cp -f "${SCRIPT_DIR}/netlaps_teacher.png" /usr/share/pixmaps/netlaps_teacher.png 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_teacher.png" /usr/share/pixmaps/netlaps-teacher.png 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_teacher.png" /usr/share/icons/hicolor/128x128/apps/netlaps-teacher.png 2>/dev/null || true
gtk-update-icon-cache /usr/share/icons/hicolor >/dev/null 2>&1 || true

echo -e "${YELLOW}[2/4] Cài đặt Dịch vụ nền (Systemd Service)...${NC}"
if [ -f "${SCRIPT_DIR}/netlaps-teacher.service" ]; then
  cp -f "${SCRIPT_DIR}/netlaps-teacher.service" /etc/systemd/system/netlaps-teacher.service
  chmod 644 /etc/systemd/system/netlaps-teacher.service
  systemctl daemon-reload
  systemctl enable netlaps-teacher.service
fi

echo -e "${YELLOW}[3/4] Cài đặt Biểu tượng ứng dụng Desktop & Menu Dash...${NC}"
if [ -f "${SCRIPT_DIR}/netlaps-teacher.desktop" ]; then
  mkdir -p /usr/share/applications
  mkdir -p /etc/xdg/autostart
  cp -f "${SCRIPT_DIR}/netlaps-teacher.desktop" /usr/share/applications/netlaps-teacher.desktop
  cp -f "${SCRIPT_DIR}/netlaps-teacher.desktop" /etc/xdg/autostart/netlaps-teacher.desktop
  chmod 644 /usr/share/applications/netlaps-teacher.desktop
  chmod 644 /etc/xdg/autostart/netlaps-teacher.desktop
  update-desktop-database /usr/share/applications >/dev/null 2>&1 || true

  for user_home in /home/*; do
    [ -d "$user_home" ] || continue
    user_name=$(basename "${user_home}")
    for desk_dir in "${user_home}/Desktop" "${user_home}/Màn hình nền"; do
      if [ -d "$desk_dir" ]; then
        cp -f "${SCRIPT_DIR}/netlaps-teacher.desktop" "$desk_dir/netlaps-teacher.desktop"
        chmod 755 "$desk_dir/netlaps-teacher.desktop"
        chown "${user_name}:${user_name}" "$desk_dir/netlaps-teacher.desktop" 2>/dev/null || true
        su - "${user_name}" -c "gio set '$desk_dir/netlaps-teacher.desktop' metadata::trusted true" >/dev/null 2>&1 || true
        su - "${user_name}" -c "gio set '$desk_dir/netlaps-teacher.desktop' metadata::trusted yes" >/dev/null 2>&1 || true
      fi
    done
  done
fi

echo -e "${YELLOW}[4/4] Khởi động Dịch vụ & Mở giao diện NetLaps Tutor v2.7.0...${NC}"
systemctl restart netlaps-teacher.service || true

if [ -x "${INSTALL_DIR}/netlaps-teacher-app" ]; then
  nohup "${INSTALL_DIR}/netlaps-teacher-app" </dev/null >/dev/null 2>&1 &
fi

LOCAL_IP=$(hostname -I | awk '{print $1}')
echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   ✅ CÀI ĐẶT THÀNH CÔNG NETLAPS TUTOR v2.7.0 TRÊN UBUNTU LINUX!              ${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo -e "📡 ĐỊA CHỈ IP MÁY GIÁO VIÊN (NHẬP VÀO MÁY HỌC SINH): ${LOCAL_IP}:5055"
echo -e "🖥️ CÁCH SỬ DỤNG:"
echo -e "   1. Cửa sổ ứng dụng NetLaps Tutor đang tự động mở trên màn hình của bạn."
echo -e "   2. Bạn cũng có thể bấm vào biểu tượng 'NetLaps Tutor' ngoài Desktop hoặc Menu Ứng dụng."
echo -e "   3. Hoặc chạy lệnh trong Terminal: netlaps-teacher-gui (hoặc netlaps-teacher)"
echo -e "${BLUE}==============================================================================${NC}"
