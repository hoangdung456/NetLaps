==============================================================================
   NETLAPS TEACHER SERVER FOR UBUNTU LINUX v2.5.6 - HUONG DAN CAI DAT
==============================================================================

1. CAI DAT NHANH BANG 1 LENH (SHELL):
   $ sudo bash install.sh

2. CAI DAT BANG GOI .DEB TRUC TIEP:
   $ sudo dpkg -i netlaps-teacher_2.5.6_amd64.deb
   hoac: sudo apt install ./netlaps-teacher_2.5.6_amd64.deb

3. TRUY CAP BANG DIEU KHIEN GIANG DAY:
   Mo trinh duyet (Firefox / Chrome) tai dia chi:
   http://localhost:8080/ hoac http://<IP_MAY_GIAO_VIEN>:8080/

4. QUAN LY DICH VU:
   - Trang thai:    sudo systemctl status netlaps-teacher
   - Khoi dong lai: sudo systemctl restart netlaps-teacher
   - Nhat ky:       sudo journalctl -u netlaps-teacher -f
   - Go bo:         sudo bash uninstall.sh

Lien he ho tro: 0385545556 | fb.com/HdMarketing98 | t.me/ytbgoogle
==============================================================================
