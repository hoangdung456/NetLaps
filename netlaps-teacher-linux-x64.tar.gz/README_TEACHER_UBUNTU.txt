==============================================================================
   NETLAPS TUTOR (GIAO VIEN) FOR UBUNTU LINUX v2.7.0 - HUONG DAN CAI DAT
==============================================================================

1. CAI DAT NHANH BANG 1 LENH (SHELL):
   $ sudo bash install.sh

2. CAI DAT BANG GOI .DEB TRUC TIEP:
   $ sudo dpkg -i netlaps-teacher_2.7.0_amd64.deb
   hoac: sudo apt install ./netlaps-teacher_2.7.0_amd64.deb

3. MO GIAO DIEN UNG DUNG GIAO VIEN:
   - Ung dung tu dong mo ngay sau khi cai dat xong.
   - Bam vao bieu tuong 'NetLaps Tutor' ngoai Desktop hoac Menu Ung dung.
   - Hoac go lenh trong Terminal: netlaps-teacher-gui (hoac netlaps-teacher)
   - Cong TCP nhan may hoc sinh: 5055 (UDP Discovery: 5056)

4. QUAN LY DICH VU:
   - Trang thai:    sudo systemctl status netlaps-teacher
   - Khoi dong lai: sudo systemctl restart netlaps-teacher
   - Go bo:         sudo bash uninstall.sh

Lien he ho tro: 0385545556 | fb.com/HdMarketing98
==============================================================================
