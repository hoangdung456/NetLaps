==============================================================================
   NETLAPS STUDENT FOR UBUNTU LINUX v2.5.6 - HUONG DAN CAI DAT PHONG MAY
==============================================================================

1. CAI DAT NHANH BANG 1 LENH (SHELL):
   $ sudo bash install.sh

2. CAI DAT BANG GOI .DEB TRUC TIEP:
   $ sudo dpkg -i netlaps-student_2.5.6_amd64.deb
   hoac: sudo apt install ./netlaps-student_2.5.6_amd64.deb

3. CAI DAT HANG LOAT CHO 1000 MAY QUA MANG LAN:
   $ bash cai_dat_hang_loat_ubuntu.sh

4. QUAN LY DICH VU:
   - Trang thai:    sudo systemctl status netlaps-student
   - Khoi dong lai: sudo systemctl restart netlaps-student
   - Nhat ky:       sudo journalctl -u netlaps-student -f
   - Go bo:         sudo bash uninstall.sh

Lien he ho tro: 0385545556 | fb.com/HdMarketing98 | t.me/ytbgoogle
==============================================================================
