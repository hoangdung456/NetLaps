==============================================================================
   NETLAPS STUDENT FOR UBUNTU LINUX v2.7.0 - HUONG DAN CAI DAT PHONG MAY
==============================================================================

1. CAI DAT NHANH BANG 1 LENH (SHELL):
   $ sudo bash install.sh

2. CAI DAT BANG GOI .DEB TRUC TIEP:
   $ sudo dpkg -i netlaps-student_2.7.0_amd64.deb
   hoac: sudo apt install ./netlaps-student_2.7.0_amd64.deb

3. MO CUA SO THIET LAP KET NOI PHONG MAY (SETUP WIZARD):
   - Bam vao bieu tuong 'Thiet Lap NetLaps Student' ngoai Desktop hoac Menu
   - Hoac go lenh trong Terminal: netlaps-student-setup

4. QUAN LY DICH VU:
   - Trang thai:    sudo systemctl status netlaps-student
   - Khoi dong lai: sudo systemctl restart netlaps-student
   - Go bo:         sudo bash uninstall.sh

Lien he ho tro: 0385545556 | fb.com/HdMarketing98
==============================================================================
