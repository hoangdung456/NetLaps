#!/usr/bin/env bash
# NetLaps Student Linux Uninstaller v2.5.6
set -e

if [ "$EUID" -ne 0 ]; then
  echo "Vui lòng chạy với quyền sudo: sudo bash uninstall.sh"
  exit 1
fi

echo "Đang gỡ cài đặt NetLaps Student..."
systemctl stop netlaps-student.service 2>/dev/null || true
systemctl disable netlaps-student.service 2>/dev/null || true
rm -f /etc/systemd/system/netlaps-student.service
systemctl daemon-reload

rm -rf /opt/netlaps-student
rm -f /usr/share/applications/netlaps-student.desktop
rm -f /usr/share/pixmaps/netlaps_student.png
rm -f /etc/xdg/autostart/netlaps-student.desktop
rm -f /tmp/netlaps_* 2>/dev/null || true

for user_home in /home/*; do
  rm -f "${user_home}/Desktop/netlaps-student.desktop" 2>/dev/null || true
done

echo "✅ ĐÃ GỠ BỎ NETLAPS STUDENT HOÀN TOÀN KHỎI HỆ THỐNG!"
