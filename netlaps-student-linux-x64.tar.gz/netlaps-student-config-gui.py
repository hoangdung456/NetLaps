#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Student - Graphical Connection Setup Wizard for Ubuntu Linux v2.7.0
Hỗ trợ tự động cả GTK3 (có sẵn 100% trên mọi máy Ubuntu Desktop) và Tkinter!
Đồng nhất giao diện và trải nghiệm 100% với bản Windows Setup Wizard
Hotline / Zalo: 0385545556 | fb.com/HdMarketing98
"""

import os
import sys
import time
import json
import socket
import subprocess

CONFIG_TMP_PATH = "/tmp/netlaps_student_config.json"
CONFIG_SYSTEM_PATH = "/etc/netlaps/student.json"
CONFIG_USER_DIR = os.path.expanduser("~/.config/netlaps")
CONFIG_USER_PATH = os.path.join(CONFIG_USER_DIR, "student.json")
STATUS_FILES = ["/etc/netlaps/status.json", "/tmp/netlaps_student_status.json"]


def resolve_config_read_path():
    candidates = [CONFIG_TMP_PATH, CONFIG_SYSTEM_PATH, CONFIG_USER_PATH]
    existing = [p for p in candidates if os.path.exists(p)]
    if existing:
        existing.sort(key=lambda p: os.path.getmtime(p), reverse=True)
        return existing[0]
    return CONFIG_SYSTEM_PATH


def load_current_config():
    p = resolve_config_read_path()
    hostname = socket.gethostname()
    seat_default = hostname if hostname.upper().startswith("UBU-") else f"UBU-{hostname}"
    cfg = {
        "RoomId": "LAB-01",
        "RoomSecret": "NetClass2026",
        "SeatCode": seat_default,
        "StudentName": "",
        "TeacherHost": "",
        "TeacherPort": 5055,
        "RelayHost": "",
        "RelayPort": 5057,
        "AdminPin": "123456",
        "AutoDiscover": True,
        "ThumbnailFps": 2,
        "EnableLockOverlay": True
    }
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
                cfg.update(data)
        except Exception:
            pass
    return cfg


def save_config(cfg):
    payload = json.dumps(cfg, indent=2, ensure_ascii=False)
    # 1. User config in ~/.config/netlaps/student.json
    try:
        os.makedirs(CONFIG_USER_DIR, exist_ok=True)
        with open(CONFIG_USER_PATH, "w", encoding="utf-8") as f:
            f.write(payload)
    except Exception:
        pass

    # 2. System config in /etc/netlaps/student.json
    try:
        os.makedirs("/etc/netlaps", exist_ok=True)
        with open(CONFIG_SYSTEM_PATH, "w", encoding="utf-8") as f:
            f.write(payload)
        try:
            os.chmod(CONFIG_SYSTEM_PATH, 0o666)
        except Exception:
            pass
    except Exception:
        pass

    # 3. Tmp config (delete first to avoid fs.protected_regular restriction)
    try:
        if os.path.exists(CONFIG_TMP_PATH):
            try:
                os.remove(CONFIG_TMP_PATH)
            except Exception:
                pass
        with open(CONFIG_TMP_PATH, "w", encoding="utf-8") as f:
            f.write(payload)
        try:
            os.chmod(CONFIG_TMP_PATH, 0o666)
        except Exception:
            pass
    except Exception:
        pass


def apply_and_start_services(cfg):
    save_config(cfg)

    # 1. Send new configuration directly via TCP port 5059 loopback to running daemon
    daemon_notified = False
    try:
        with socket.create_connection(("127.0.0.1", 5059), timeout=2.0) as s:
            payload = json.dumps(cfg, ensure_ascii=False)
            s.sendall(f"CONFIG|{payload}\n".encode("utf-8"))
            s.settimeout(2.5)
            resp = s.recv(512).decode("utf-8", errors="ignore")
            if "OK" in resp:
                daemon_notified = True
    except Exception:
        pass

    # 2. If daemon not reached on port 5059, try restarting systemd service
    if not daemon_notified:
        try:
            subprocess.run(["systemctl", "restart", "netlaps-student"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
        except Exception:
            pass

    # 3. If daemon still not running, spawn netlaps-student directly with CLI arguments
    try:
        cmd = [
            "/opt/netlaps-student/netlaps-student",
            "--room", cfg.get("RoomId", "LAB-01"),
            "--secret", cfg.get("RoomSecret", "NetClass2026")
        ]
        if cfg.get("TeacherHost"):
            cmd.extend(["--teacher", str(cfg.get("TeacherHost"))])
            cmd.extend(["--port", str(cfg.get("TeacherPort", 5055))])
        if cfg.get("SeatCode"):
            cmd.extend(["--seat", str(cfg.get("SeatCode"))])
        if cfg.get("StudentName"):
            cmd.extend(["--name", str(cfg.get("StudentName"))])

        if os.path.exists("/opt/netlaps-student/netlaps-student"):
            subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
    except Exception:
        pass

    # 4. Ensure desktop student toolbar is running
    try:
        chk_bar = subprocess.run(["pgrep", "-f", "netlaps-student-bar.py"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if chk_bar.returncode != 0 and os.path.exists("/opt/netlaps-student/netlaps-student-bar.py"):
            subprocess.Popen(
                ["python3", "/opt/netlaps-student/netlaps-student-bar.py"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
    except Exception:
        pass

    connected_ok = False
    for _ in range(12):
        time.sleep(0.25)
        for st_path in STATUS_FILES:
            if os.path.exists(st_path):
                try:
                    with open(st_path, "r", encoding="utf-8") as sf:
                        st_data = json.load(sf)
                        if st_data.get("connected") is True:
                            connected_ok = True
                            break
                except Exception:
                    pass
        if connected_ok:
            break
    return connected_ok


def parse_host_port(raw_str, default_port):
    raw_str = (raw_str or "").strip()
    if not raw_str:
        return "", default_port
    for prefix in ("http://", "https://", "tcp://"):
        if raw_str.lower().startswith(prefix):
            raw_str = raw_str[len(prefix):]
    raw_str = raw_str.rstrip("/").strip()
    if not raw_str:
        return "", default_port
    if ":" in raw_str:
        parts = raw_str.rsplit(":", 1)
        host = parts[0].strip()
        try:
            port = int(parts[1].strip())
        except ValueError:
            port = default_port
        return host, port
    return raw_str, default_port


def run_gtk_wizard():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, Gdk

    cfg = load_current_config()

    win = Gtk.Window(title="Setup - NetLaps Student version 2.7.0")
    win.set_default_size(660, 500)
    win.set_resizable(False)
    win.set_position(Gtk.WindowPosition.CENTER)
    if os.path.exists("/opt/netlaps-student/netlaps_student.png"):
        try:
            win.set_icon_from_file("/opt/netlaps-student/netlaps_student.png")
        except Exception:
            pass

    css = b"""
    window { background-color: #F0F0F0; }
    .header-box { background-color: #FFFFFF; border-bottom: 1px solid #CBD5E1; padding: 14px 20px; }
    .title-lbl { color: #0F172A; font-weight: bold; font-size: 15px; }
    .sub-lbl { color: #475569; font-size: 11.5px; }
    .field-lbl { color: #0F172A; font-size: 12.5px; }
    .field-lbl-blue { color: #0284C7; font-weight: bold; font-size: 12.5px; }
    .footer-box { background-color: #E2E8F0; border-top: 1px solid #CBD5E1; padding: 10px 18px; }
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

    vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    win.add(vbox)

    # Header
    header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
    header.get_style_context().add_class("header-box")
    lbl_t = Gtk.Label(label="Thiết lập Kết nối Phòng máy NetLaps Student", xalign=0)
    lbl_t.get_style_context().add_class("title-lbl")
    lbl_s = Gtk.Label(label="Máy Học sinh KHÔNG cần nhập Key kích hoạt. Nhập thông số phòng máy (hỗ trợ /ROOM, /SECRET, /PIN):", xalign=0)
    lbl_s.get_style_context().add_class("sub-lbl")
    header.pack_start(lbl_t, False, False, 0)
    header.pack_start(lbl_s, False, False, 0)
    vbox.pack_start(header, False, False, 0)

    # Body
    body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    body.set_margin_top(16)
    body.set_margin_bottom(12)
    body.set_margin_start(26)
    body.set_margin_end(26)

    lbl_note = Gtk.Label(
        label="Để trống ô IP Giáo viên nếu dùng mạng LAN tự động nhận diện. Nhập địa chỉ IP:Port Máy Giáo viên để kết nối trực tiếp tức thì:",
        xalign=0
    )
    lbl_note.set_line_wrap(True)
    body.pack_start(lbl_note, False, False, 4)

    def add_entry(label_text, init_val, is_highlight=False):
        lbl = Gtk.Label(label=label_text, xalign=0)
        lbl.get_style_context().add_class("field-lbl-blue" if is_highlight else "field-lbl")
        body.pack_start(lbl, False, False, 0)
        ent = Gtk.Entry()
        ent.set_text(str(init_val or ""))
        body.pack_start(ent, False, False, 2)
        return ent

    ent_room = add_entry("Mã Phòng học (Room ID):", cfg.get("RoomId", "LAB-01"))
    ent_secret = add_entry("Mật khẩu Phòng (Room Secret):", cfg.get("RoomSecret", "NetClass2026"))

    th = cfg.get("TeacherHost", "")
    tp = cfg.get("TeacherPort", 5055)
    ent_teacher = add_entry(
        "IP:Port Máy Giáo viên trực tiếp (Tùy chọn, VD 192.168.100.163:5055):",
        f"{th}:{tp}" if th else "",
        is_highlight=True
    )

    rh = cfg.get("RelayHost", "")
    rp = cfg.get("RelayPort", 5057)
    ent_gateway = add_entry(
        "Host:Port Máy chủ NetLaps Gateway (Tùy chọn, VD gateway.truong.edu.vn:5057):",
        f"{rh}:{rp}" if rh else ""
    )

    ent_pin = add_entry("Mã PIN Quản trị máy Học sinh (Admin PIN):", cfg.get("AdminPin", "123456"))

    lbl_status = Gtk.Label(label="", xalign=0)
    body.pack_start(lbl_status, False, False, 4)
    vbox.pack_start(body, True, True, 0)

    # Footer
    footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    footer.get_style_context().add_class("footer-box")

    btn_cancel = Gtk.Button(label="Cancel")
    btn_cancel.set_size_request(95, 32)
    btn_cancel.connect("clicked", lambda *_: Gtk.main_quit())

    btn_next = Gtk.Button(label="Next >")
    btn_next.set_size_request(110, 32)

    btn_back = Gtk.Button(label="< Back")
    btn_back.set_size_request(95, 32)
    btn_back.set_sensitive(False)

    footer.pack_end(btn_cancel, False, False, 0)
    footer.pack_end(btn_next, False, False, 0)
    footer.pack_end(btn_back, False, False, 0)
    vbox.pack_end(footer, False, False, 0)

    def show_msg(title, text, msg_type=Gtk.MessageType.INFO):
        dlg = Gtk.MessageDialog(
            transient_for=win,
            flags=0,
            message_type=msg_type,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        dlg.format_secondary_text(text)
        dlg.run()
        dlg.destroy()

    def ask_yes_no(title, text):
        dlg = Gtk.MessageDialog(
            transient_for=win,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=title
        )
        dlg.format_secondary_text(text)
        resp = dlg.run()
        dlg.destroy()
        return resp == Gtk.ResponseType.YES

    def on_next_clicked(_btn):
        room = ent_room.get_text().strip().upper() or "LAB-01"
        secret = ent_secret.get_text().strip() or "NetClass2026"
        teacher_host, teacher_port = parse_host_port(ent_teacher.get_text(), 5055)
        relay_host, relay_port = parse_host_port(ent_gateway.get_text(), 5057)
        pin = ent_pin.get_text().strip() or "123456"

        if teacher_host:
            lbl_status.set_text(f"Đang kiểm tra kết nối tới máy Giáo viên {teacher_host}:{teacher_port}...")
            while Gtk.events_pending():
                Gtk.main_iteration()
            try:
                with socket.create_connection((teacher_host, teacher_port), timeout=2.5):
                    pass
            except Exception as ex:
                if ask_yes_no(
                    "Không thể kết nối tới IP Máy Giáo viên",
                    f"Không thể kết nối tới {teacher_host}:{teacher_port} ({ex}).\n"
                    f"Bạn có muốn sửa lại địa chỉ IP trước khi lưu không?"
                ):
                    return

        cfg["RoomId"] = room
        cfg["RoomSecret"] = secret
        cfg["TeacherHost"] = teacher_host
        cfg["TeacherPort"] = teacher_port
        cfg["RelayHost"] = relay_host
        cfg["RelayPort"] = relay_port
        cfg["AdminPin"] = pin
        cfg["AutoDiscover"] = True

        lbl_status.set_text("Đang lưu cấu hình và kết nối với máy chủ Giáo viên...")
        while Gtk.events_pending():
            Gtk.main_iteration()

        connected_ok = apply_and_start_services(cfg)
        target_display = f"{teacher_host}:{teacher_port}" if teacher_host else "Tự động dò tìm mạng LAN"
        status_line = "✅ ĐÃ KẾT NỐI TRỰC TIẾP VỚI MÁY GIÁO VIÊN!" if connected_ok else "🔄 Đã lưu cấu hình, đang tự động dò tìm & kết nối ngầm..."
        show_msg(
            "NetLaps Student Setup",
            f"{status_line}\n\n• Phòng học: [{room}]\n• Máy Giáo viên: [{target_display}]\n• Máy Học sinh sẽ xuất hiện ngay trên màn hình quản lý của Giáo viên."
        )
        Gtk.main_quit()

    btn_next.connect("clicked", on_next_clicked)
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()


def run_tk_wizard():
    import tkinter as tk
    from tkinter import ttk, messagebox

    cfg = load_current_config()
    root = tk.Tk()
    root.title("Setup - NetLaps Student version 2.7.0")
    root.geometry("680x520")
    root.resizable(False, False)
    root.configure(bg="#F0F0F0")
    try:
        root.eval('tk::PlaceWindow . center')
    except Exception:
        pass

    header_frame = tk.Frame(root, bg="#FFFFFF", height=82)
    header_frame.pack(fill="x", side="top")
    header_frame.pack_propagate(False)

    title_box = tk.Frame(header_frame, bg="#FFFFFF")
    title_box.pack(side="left", padx=20, pady=12)

    tk.Label(title_box, text="Thiết lập Kết nối Phòng máy NetLaps Student", font=("Segoe UI", 11, "bold"), bg="#FFFFFF", fg="#0F172A").pack(anchor="w")
    tk.Label(title_box, text="Máy Học sinh KHÔNG cần nhập Key kích hoạt. Nhập thông số phòng máy (hỗ trợ /ROOM, /SECRET, /PIN):", font=("Segoe UI", 8), bg="#FFFFFF", fg="#475569").pack(anchor="w", pady=(3, 0))

    tk.Frame(root, bg="#CBD5E1", height=1).pack(fill="x", side="top")
    body = tk.Frame(root, bg="#F0F0F0", padx=30, pady=18)
    body.pack(fill="both", expand=True)

    tk.Label(
        body,
        text="Để trống ô IP Giáo viên nếu dùng mạng LAN tự động nhận diện. Nhập địa chỉ IP:Port Máy Giáo viên để kết nối trực tiếp tức thì:",
        font=("Segoe UI", 9), bg="#F0F0F0", fg="#1E293B", wraplength=620, justify="left"
    ).pack(anchor="w", pady=(0, 14))

    form = tk.Frame(body, bg="#F0F0F0")
    form.pack(fill="x")

    def add_field(lbl_txt, val, bold=False):
        tk.Label(form, text=lbl_txt, font=("Segoe UI", 9, "bold") if bold else ("Segoe UI", 9), bg="#F0F0F0", fg="#0284C7" if bold else "#0F172A").pack(anchor="w")
        e = ttk.Entry(form, font=("Segoe UI", 9, "bold") if bold else ("Segoe UI", 9))
        e.insert(0, str(val or ""))
        e.pack(fill="x", pady=(2, 8))
        return e

    txt_room = add_field("Mã Phòng học (Room ID):", cfg.get("RoomId", "LAB-01"))
    txt_secret = add_field("Mật khẩu Phòng (Room Secret):", cfg.get("RoomSecret", "NetClass2026"))
    th = cfg.get("TeacherHost", "")
    tp = cfg.get("TeacherPort", 5055)
    txt_teacher = add_field("IP:Port Máy Giáo viên trực tiếp (Tùy chọn, VD 192.168.100.163:5055):", f"{th}:{tp}" if th else "", bold=True)
    rh = cfg.get("RelayHost", "")
    rp = cfg.get("RelayPort", 5057)
    txt_gateway = add_field("Host:Port Máy chủ NetLaps Gateway (Tùy chọn, VD gateway.truong.edu.vn:5057):", f"{rh}:{rp}" if rh else "")
    txt_pin = add_field("Mã PIN Quản trị máy Học sinh (Admin PIN):", cfg.get("AdminPin", "123456"))

    lbl_status = tk.Label(body, text="", font=("Segoe UI", 8, "italic"), bg="#F0F0F0", fg="#0284C7")
    lbl_status.pack(anchor="w", pady=(4, 0))

    footer = tk.Frame(root, bg="#E2E8F0", height=48)
    footer.pack(fill="x", side="bottom")
    footer.pack_propagate(False)
    btn_box = tk.Frame(footer, bg="#E2E8F0")
    btn_box.pack(side="right", padx=16, pady=8)

    def on_submit():
        room = txt_room.get().strip().upper() or "LAB-01"
        secret = txt_secret.get().strip() or "NetClass2026"
        teacher_host, teacher_port = parse_host_port(txt_teacher.get(), 5055)
        relay_host, relay_port = parse_host_port(txt_gateway.get(), 5057)
        pin = txt_pin.get().strip() or "123456"

        cfg["RoomId"] = room
        cfg["RoomSecret"] = secret
        cfg["TeacherHost"] = teacher_host
        cfg["TeacherPort"] = teacher_port
        cfg["RelayHost"] = relay_host
        cfg["RelayPort"] = relay_port
        cfg["AdminPin"] = pin
        cfg["AutoDiscover"] = True

        lbl_status.config(text="Đang áp dụng cấu hình và đồng bộ với máy chủ Giáo viên...")
        root.update()
        connected_ok = apply_and_start_services(cfg)
        target_display = f"{teacher_host}:{teacher_port}" if teacher_host else "Tự động dò tìm mạng LAN"
        status_line = "✅ ĐÃ KẾT NỐI TRỰC TIẾP VỚI MÁY GIÁO VIÊN!" if connected_ok else "🔄 Đã lưu cấu hình, đang tự động dò tìm & kết nối ngầm..."
        messagebox.showinfo("NetLaps Student Setup", f"{status_line}\n\n• Phòng học: [{room}]\n• Máy Giáo viên: [{target_display}]")
        root.destroy()

    ttk.Button(btn_box, text="Back", state="disabled", width=10).pack(side="left", padx=4)
    ttk.Button(btn_box, text="Next >", width=12, command=on_submit).pack(side="left", padx=4)
    ttk.Button(btn_box, text="Cancel", width=10, command=root.destroy).pack(side="left", padx=4)
    root.mainloop()


if __name__ == "__main__":
    try:
        run_gtk_wizard()
    except Exception:
        run_tk_wizard()
