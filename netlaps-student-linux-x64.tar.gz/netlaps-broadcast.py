#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Student Linux - Remote Teacher Screen Broadcast Viewer
Renders Teacher's live screen broadcast directly on student's Ubuntu desktop.
"""

import sys
import os
import signal
import time

try:
    import tkinter as tk
except ImportError:
    print("Tkinter not installed, skipping broadcast window.")
    sys.exit(0)

# Check if PIL is available
HAS_PIL = False
try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    pass

STREAM_FILE = "/tmp/netlaps_teacher_frame.jpg"
STOP_FLAG = "/tmp/netlaps_broadcast_stop.flag"

class BroadcastViewer:
    def __init__(self, root):
        self.root = root
        self.root.title("NetLaps — Trình chiếu Màn hình Giáo viên")
        self.root.attributes("-fullscreen", True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg="#000000")

        # Top Bar
        top_bar = tk.Frame(root, bg="#1E1E2E", height=32)
        top_bar.pack(side="top", fill="x")

        lbl_info = tk.Label(
            top_bar,
            text="📡 NETLAPS — ĐANG THEO DÕI BÀI GIẢNG TRỰC TIẾP TỪ MÁY GIÁO VIÊN",
            font=("DejaVu Sans", 11, "bold"),
            fg="#50FA7B",
            bg="#1E1E2E"
        )
        lbl_info.pack(side="left", padx=15, pady=4)

        # Canvas for display
        self.canvas = tk.Label(root, bg="#000000")
        self.canvas.pack(expand=True, fill="both")

        self.last_mtime = 0
        self.photo_ref = None

        self.check_frames()

    def check_frames(self):
        if os.path.exists(STOP_FLAG):
            try: os.remove(STOP_FLAG)
            except: pass
            self.root.destroy()
            return

        if os.path.exists(STREAM_FILE):
            try:
                mtime = os.path.getmtime(STREAM_FILE)
                if mtime > self.last_mtime:
                    self.last_mtime = mtime
                    if HAS_PIL:
                        img = Image.open(STREAM_FILE)
                        # Resize to fit screen
                        sw = self.root.winfo_screenwidth()
                        sh = self.root.winfo_screenheight() - 32
                        img = img.resize((sw, sh), Image.Resampling.LANCZOS)
                        self.photo_ref = ImageTk.PhotoImage(img)
                        self.canvas.configure(image=self.photo_ref)
                    else:
                        # Fallback PPM / PNG
                        ppm_file = "/tmp/netlaps_teacher_frame.ppm"
                        if os.path.exists(ppm_file):
                            self.photo_ref = tk.PhotoImage(file=ppm_file)
                            self.canvas.configure(image=self.photo_ref)
            except:
                pass

        self.root.after(60, self.check_frames) # ~16 FPS refresh loop

if __name__ == "__main__":
    if os.path.exists(STOP_FLAG):
        try: os.remove(STOP_FLAG)
        except: pass

    root = tk.Tk()
    app = BroadcastViewer(root)
    root.mainloop()
