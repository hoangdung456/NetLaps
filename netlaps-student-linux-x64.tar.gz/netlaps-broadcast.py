#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Student Linux - Remote Teacher Screen Broadcast Viewer v2.7.0
Hỗ trợ tự động cả GTK3 GdkPixbuf (có sẵn 100% trên mọi máy Ubuntu Desktop) và Tkinter!
"""

import sys
import os
import signal
import time

STREAM_FILES = ["/etc/netlaps/teacher_frame.jpg", "/tmp/netlaps_teacher_frame.jpg"]
STOP_FLAGS = ["/etc/netlaps/broadcast_stop.flag", "/tmp/netlaps_broadcast_stop.flag"]


def is_stop_requested():
    for p in STOP_FLAGS:
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass
            return True
    return False


def clear_stop_flags():
    for p in STOP_FLAGS:
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass


def find_stream_file():
    for p in STREAM_FILES:
        if os.path.exists(p):
            return p
    return STREAM_FILES[0]


def run_gtk_broadcast():
    import gi
    gi.require_version("Gtk", "3.0")
    gi.require_version("GdkPixbuf", "2.0")
    from gi.repository import Gtk, Gdk, GdkPixbuf, GLib

    win = Gtk.Window(title="NetLaps — Trình chiếu Màn hình Giáo viên v2.7.0")
    win.set_decorated(False)
    win.set_keep_above(True)
    win.fullscreen()

    css = b"""
    window { background-color: #000000; color: #FFFFFF; }
    .top-bar { background-color: #0F172A; padding: 6px 16px; }
    .top-lbl { color: #10B981; font-weight: bold; font-size: 13px; }
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

    vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    win.add(vbox)

    top_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    top_bar.get_style_context().add_class("top-bar")
    lbl_info = Gtk.Label(label="📡 NETLAPS v2.7.0 — ĐANG THEO DÕI BÀI GIẢNG TRỰC TIẾP TỪ MÁY GIÁO VIÊN", xalign=0)
    lbl_info.get_style_context().add_class("top-lbl")
    top_bar.pack_start(lbl_info, True, True, 0)
    vbox.pack_start(top_bar, False, False, 0)

    img_widget = Gtk.Image()
    vbox.pack_start(img_widget, True, True, 0)

    win.connect("delete-event", lambda *_: True)

    state = {"last_mtime": 0.0}
    screen = Gdk.Screen.get_default()
    sw = screen.get_width() if screen else 1920
    sh = (screen.get_height() - 36) if screen else 1044

    def tick():
        if is_stop_requested():
            Gtk.main_quit()
            return False

        sf = find_stream_file()
        if os.path.exists(sf):
            try:
                mtime = os.path.getmtime(sf)
                if mtime > state["last_mtime"]:
                    state["last_mtime"] = mtime
                    pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(sf, sw, sh, True)
                    img_widget.set_from_pixbuf(pb)
            except Exception:
                pass
        return True

    tick()
    GLib.timeout_add(60, tick)
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    signal.signal(signal.SIGINT, lambda *_: sys.exit(0))
    clear_stop_flags()
    try:
        run_gtk_broadcast()
    except Exception:
        pass
