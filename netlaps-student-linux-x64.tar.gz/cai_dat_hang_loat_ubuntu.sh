#!/usr/bin/env bash
# ==============================================================================
# NETLAPS v2.5.6 — KỊCH BẢN TRIỂN KHAI CÀI ĐẶT HÀNG LOẠT CHO MÁY UBUNTU LINUX
# Tự động đẩy bộ cài qua SSH / LAN và kích hoạt chạy ngầm toàn bộ phòng máy
# Hotline / Zalo hỗ trợ: 0385545556 | Facebook: fb.com/HdMarketing98
# ==============================================================================

# Danh sách dải IP phòng máy (hoặc nhập từ tệp danh_sach_ip.txt)
# Ví dụ phòng 1: 192.168.1.10 đến 192.168.1.60
SUBNET_PREFIX="192.168.1"
START_HOST=10
END_HOST=60
SSH_USER="student"       # Tên người dùng quản trị trên máy học sinh
SSH_PASS="123456"        # Mật khẩu SSH học sinh (nếu dùng mật khẩu)

PACKAGE_ARCHIVE="netlaps-student-linux-x64.tar.gz"

echo "=============================================================================="
echo "   🚀 BẮT ĐẦU CÀI ĐẶT HÀNG LOẠT NETLAPS STUDENT TRÊN MẠNG LAN UBUNTU LINUX    "
echo "=============================================================================="

if [ ! -f "${PACKAGE_ARCHIVE}" ]; then
  echo "[LỖI] Không tìm thấy tệp ${PACKAGE_ARCHIVE}. Hãy đặt tệp cùng thư mục với script này!"
  exit 1
fi

for host in $(seq $START_HOST $END_HOST); do
  TARGET_IP="${SUBNET_PREFIX}.${host}"
  echo -n "[DEPLOY] Đang kiểm tra ${TARGET_IP}... "

  if ping -c 1 -W 1 "${TARGET_IP}" >/dev/null 2>&1; then
    echo "ONLINE! Đang cài đặt..."
    (
      # Copy package qua SSH
      sshpass -p "${SSH_PASS}" scp -o StrictHostKeyChecking=no "${PACKAGE_ARCHIVE}" "${SSH_USER}@${TARGET_IP}:/tmp/" >/dev/null 2>&1
      # Giải nén và chạy install.sh
      sshpass -p "${SSH_PASS}" ssh -o StrictHostKeyChecking=no "${SSH_USER}@${TARGET_IP}" "cd /tmp && tar -xzf ${PACKAGE_ARCHIVE} && echo '${SSH_PASS}' | sudo -S bash install.sh && rm -f ${PACKAGE_ARCHIVE}" >/dev/null 2>&1
      echo "  ==> [${TARGET_IP}] ✅ Đã cài đặt và kích hoạt thành công!"
    ) &
  else
    echo "OFFLINE (Bỏ qua)"
  fi
done

wait
echo "=============================================================================="
echo "   ✅ HOÀN TẤT CÀI ĐẶT HÀNG LOẠT! HÃY BẬT MÁY GIÁO VIÊN ĐỂ KIỂM TRA.         "
echo "=============================================================================="
