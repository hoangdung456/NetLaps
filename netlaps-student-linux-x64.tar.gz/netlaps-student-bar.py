#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Student Linux - Desktop Floating Status Toolbar & Widget v2.5.6
Provides students on Ubuntu with a native desktop widget showing connection status,
room info, seat code, and interactive Raise Hand / Message features.
"""

import os
import sys
import json
import time

try:
    import tkinter as tk
    from tkinter import messagebox
except ImportError:
    print("Tkinter not found, running headless.")
    sys.exit(0)

STATUS_FILE = "/tmp/netlaps_student_status.json"
HAND_FLAG = "/tmp/netlaps_hand.flag"

class StudentToolbar:
    def __init__(self, root):
        self.root = root
        self.root.title("NetLaps Student v2.5.6")
        self.root.attributes("-topmost", True)
        self.root.configure(bg="#0F172A")
        self.root.resizable(False, False)

        # Remove window borders for floating dock bar style
        self.is_compact = False
        self.hand_raised = os.path.exists(HAND_FLAG)

        # Center at top of screen
        screen_w = self.root.winfo_screenwidth()
        bar_w = 720
        bar_h = 56
        pos_x = max(10, int((screen_w - bar_w) / 2))
        pos_y = 12
        self.root.geometry(f"{bar_w}x{bar_h}+{pos_x}+{pos_y}")

        # Dragging support
        self._drag_start_x = 0
        self._drag_start_y = 0

        # Main Container
        self.main_frame = tk.Frame(root, bg="#0F172A", bd=1, relief="ridge", highlightbackground="#334155", highlightthickness=1)
        self.main_frame.pack(fill="both", expand=True)
        self.main_frame.bind("<Button-1>", self.on_drag_start)
        self.main_frame.bind("<B1-Motion>", self.on_drag_motion)

        # Left: Brand Logo & Title
        f_left = tk.Frame(self.main_frame, bg="#0F172A")
        f_left.pack(side="left", padx=(12, 8), pady=8)
        f_left.bind("<Button-1>", self.on_drag_start)
        f_left.bind("<B1-Motion>", self.on_drag_motion)

        lbl_logo = tk.Label(f_left, text="🛡️ NetLaps", font=("DejaVu Sans", 11, "bold"), fg="#38BDF8", bg="#0F172A")
        lbl_logo.pack(side="left")
        lbl_ver = tk.Label(f_left, text="v2.5.6", font=("DejaVu Sans", 8, "bold"), fg="#64748B", bg="#1E293B", padx=4, pady=1)
        lbl_ver.pack(side="left", padx=5)

        # Middle: Room & Seat info + Status pill
        f_mid = tk.Frame(self.main_frame, bg="#0F172A")
        f_mid.pack(side="left", padx=10, pady=8)
        f_mid.bind("<Button-1>", self.on_drag_start)
        f_mid.bind("<B1-Motion>", self.on_drag_motion)

        self.lbl_seat = tk.Label(f_mid, text="Máy: ... | Phòng: ...", font=("DejaVu Sans", 10, "bold"), fg="#F8FAFC", bg="#0F172A")
        self.lbl_seat.pack(anchor="w")

        self.lbl_status = tk.Label(f_mid, text="🔄 Đang dò tìm máy Giáo viên...", font=("DejaVu Sans", 9), fg="#94A3B8", bg="#0F172A")
        self.lbl_status.pack(anchor="w")

        # Right: Interactive Action Buttons
        f_right = tk.Frame(self.main_frame, bg="#0F172A")
        f_right.pack(side="right", padx=(8, 12), pady=8)

        self.btn_hand = tk.Button(
            f_right,
            text="✋ Giơ tay",
            font=("DejaVu Sans", 9, "bold"),
            bg="#334155",
            fg="#F8FAFC",
            activebackground="#F59E0B",
            activeforeground="#000000",
            bd=0,
            padx=10,
            pady=4,
            cursor="hand2",
            command=self.toggle_hand
        )
        self.btn_hand.pack(side="left", padx=4)

        btn_info = tk.Button(
            f_right,
            text="ℹ️ Thông tin",
            font=("DejaVu Sans", 9),
            bg="#1E293B",
            fg="#CBD5E1",
            activebackground="#334155",
            bd=0,
            padx=8,
            pady=4,
            cursor="hand2",
            command=self.show_info
        )
        btn_info.pack(side="left", padx=4)

        btn_min = tk.Button(
            f_right,
            text="—",
            font=("DejaVu Sans", 10, "bold"),
            bg="#1E293B",
            fg="#94A3B8",
            activebackground="#334155",
            bd=0,
            padx=6,
            pady=2,
            cursor="hand2",
            command=self.minimize_to_compact
        )
        btn_min.pack(side="left", padx=2)

        # Polling status loop
        self.update_status()

    def on_drag_start(self, event):
        self._drag_start_x = event.x
        self._drag_start_y = event.y

    def on_drag_motion(self, event):
        x = self.root.winfo_x() - self._drag_start_x + event.x
        y = self.root.winfo_y() - self._drag_start_y + event.y
        self.root.geometry(f"+{x}+{y}")

    def toggle_hand(self):
        self.hand_raised = not self.hand_raised
        if self.hand_raised:
            try:
                with open(HAND_FLAG, "w", encoding="utf-8") as f:
                    f.write("hand")
            except:
                pass
            self.btn_hand.configure(bg="#F59E0B", fg="#000000", text="✋ ĐÃ GIƠ TAY")
        else:
            if os.path.exists(HAND_FLAG):
                try:
                    os.remove(HAND_FLAG)
                except:
                    pass
            self.btn_hand.configure(bg="#334155", fg="#F8FAFC", text="✋ Giơ tay")

    def show_info(self):
        info_text = (
            "🛡️ NetLaps Student for Ubuntu Linux v2.5.6\n\n"
            "Phần mềm Học sinh Quản lý phòng máy trường học đa nền tảng.\n"
            "Hỗ trợ: Khóa màn hình, Xem trình chiếu giáo viên, Phát/Thu tệp bài tập.\n\n"
            "Hotline / Zalo hỗ trợ: 0385545556\n"
            "Bản quyền: NetLaps Commercial VIP"
        )
        messagebox.showinfo("NetLaps Student v2.5.6", info_text)

    def minimize_to_compact(self):
        # Minimize window to standard taskbar
        self.root.iconify()

    def update_status(self):
        if os.path.exists(STATUS_FILE):
            try:
                with open(STATUS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)

                room = data.get("roomId", "LAB-01")
                seat = data.get("seatCode", "Học sinh")
                connected = data.get("connected", False)
                host = data.get("teacherHost", "")
                is_locked = data.get("isLocked", False)

                self.lbl_seat.config(text=f"Bàn máy: {seat}  •  Phòng: [{room}]")
                if connected:
                    self.lbl_status.config(text=f"✅ ĐÃ KẾT NỐI GIÁO VIÊN ({host})", fg="#10B981")
                else:
                    self.lbl_status.config(text="🔄 Đang tìm máy Giáo viên qua mạng LAN...", fg="#F59E0B")

                if is_locked:
                    self.lbl_status.config(text="🔒 ĐANG TẠM KHÓA BỞI GIÁO VIÊN", fg="#EF4444")
            except:
                pass
        else:
            self.lbl_status.config(text="🔄 Đang khởi động dịch vụ NetLaps Student...", fg="#94A3B8")

        # Sync hand button state
        if os.path.exists(HAND_FLAG):
            self.btn_hand.configure(bg="#F59E0B", fg="#000000", text="✋ ĐÃ GIƠ TAY")
        else:
            self.btn_hand.configure(bg="#334155", fg="#F8FAFC", text="✋ Giơ tay")

        self.root.after(1000, self.update_status)

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentToolbar(root)
    root.mainloop()
