#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Student Linux - Desktop Floating Status Toolbar & Widget v2.7.0
Hỗ trợ tự động cả GTK3 (có sẵn 100% trên mọi máy Ubuntu Desktop) và Tkinter!
"""

import os
import sys
import json
import time
import subprocess

STATUS_FILES = ["/etc/netlaps/status.json", "/tmp/netlaps_student_status.json"]
HAND_FLAG = "/etc/netlaps/hand.flag"


def read_status_and_ensure_daemon(last_spawn_holder):
    need_start = False
    seat = "Học sinh"
    room = "LAB-01"
    connected = False
    host = ""
    is_locked = False

    status_path = next((p for p in STATUS_FILES if os.path.exists(p)), None)
    if status_path:
        try:
            mtime = os.path.getmtime(status_path)
            if time.time() - mtime > 8:
                need_start = True
            with open(status_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            room = data.get("roomId", "LAB-01")
            seat = data.get("seatCode", "Học sinh")
            connected = data.get("connected", False)
            host = data.get("teacherHost", "")
            is_locked = data.get("isLocked", False)
        except Exception:
            need_start = True
    else:
        need_start = True

    if need_start and last_spawn_holder[0] < time.time() - 5:
        last_spawn_holder[0] = time.time()
        if os.path.exists("/opt/netlaps-student/netlaps-student"):
            try:
                subprocess.Popen(
                    ["/opt/netlaps-student/netlaps-student"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True
                )
            except Exception:
                pass

    return seat, room, connected, host, is_locked


def open_setup_wizard():
    if os.path.exists("/opt/netlaps-student/netlaps-student-config-gui.py"):
        try:
            subprocess.Popen(
                ["python3", "/opt/netlaps-student/netlaps-student-config-gui.py"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True
            )
        except Exception:
            pass


def run_gtk_bar():
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, Gdk, GLib

    win = Gtk.Window(title="NetLaps Student v2.7.0")
    win.set_default_size(640, 56)
    win.set_resizable(False)
    win.set_keep_above(True)
    if os.path.exists("/opt/netlaps-student/netlaps_student.png"):
        try:
            win.set_icon_from_file("/opt/netlaps-student/netlaps_student.png")
        except Exception:
            pass

    screen = Gdk.Screen.get_default()
    if screen:
        sw = screen.get_width()
        win.move(max(10, int((sw - 640) / 2)), 28)

    css = b"""
    window { background-color: #0F172A; color: #F8FAFC; }
    .logo-lbl { color: #38BDF8; font-weight: bold; font-size: 13px; }
    .ver-lbl { background-color: #1E293B; color: #94A3B8; font-size: 10px; padding: 2px 6px; border-radius: 4px; }
    .seat-lbl { color: #F8FAFC; font-weight: bold; font-size: 12px; }
    .st-ok { color: #10B981; font-weight: bold; font-size: 11px; }
    .st-wait { color: #F59E0B; font-size: 11px; }
    .st-lock { color: #EF4444; font-weight: bold; font-size: 11px; }
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

    hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    hbox.set_margin_top(8)
    hbox.set_margin_bottom(8)
    hbox.set_margin_start(12)
    hbox.set_margin_end(12)
    win.add(hbox)

    lbl_logo = Gtk.Label(label="🛡️ NetLaps")
    lbl_logo.get_style_context().add_class("logo-lbl")
    hbox.pack_start(lbl_logo, False, False, 0)

    lbl_ver = Gtk.Label(label="v2.7.0")
    lbl_ver.get_style_context().add_class("ver-lbl")
    hbox.pack_start(lbl_ver, False, False, 0)

    vbox_mid = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
    lbl_seat = Gtk.Label(label="Máy: ... | Phòng: ...", xalign=0)
    lbl_seat.get_style_context().add_class("seat-lbl")
    lbl_status = Gtk.Label(label="🔄 Đang dò tìm máy Giáo viên...", xalign=0)
    lbl_status.get_style_context().add_class("st-wait")
    vbox_mid.pack_start(lbl_seat, False, False, 0)
    vbox_mid.pack_start(lbl_status, False, False, 0)
    hbox.pack_start(vbox_mid, True, True, 6)

    btn_hand = Gtk.Button(label="✋ Giơ tay")
    btn_cfg = Gtk.Button(label="⚙️ Kết nối")
    btn_info = Gtk.Button(label="ℹ️")

    def on_toggle_hand(_b):
        if os.path.exists(HAND_FLAG):
            try:
                os.remove(HAND_FLAG)
            except Exception:
                pass
            btn_hand.set_label("✋ Giơ tay")
        else:
            try:
                with open(HAND_FLAG, "w", encoding="utf-8") as f:
                    f.write("hand")
            except Exception:
                pass
            btn_hand.set_label("✋ ĐÃ GIƠ TAY")

    def on_show_info(_b):
        dlg = Gtk.MessageDialog(
            transient_for=win,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text="🛡️ NetLaps Student for Ubuntu Linux v2.7.0"
        )
        dlg.format_secondary_text(
            "Phần mềm Học sinh Quản lý phòng máy trường học đa nền tảng.\n"
            "Hotline / Zalo hỗ trợ: 0385545556"
        )
        dlg.run()
        dlg.destroy()

    btn_hand.connect("clicked", on_toggle_hand)
    btn_cfg.connect("clicked", lambda *_: open_setup_wizard())
    btn_info.connect("clicked", on_show_info)

    hbox.pack_end(btn_info, False, False, 0)
    hbox.pack_end(btn_cfg, False, False, 0)
    hbox.pack_end(btn_hand, False, False, 0)

    last_spawn = [0.0]

    def tick():
        seat, room, connected, host, is_locked = read_status_and_ensure_daemon(last_spawn)
        lbl_seat.set_text(f"Bàn máy: {seat}  •  Phòng: [{room}]")
        ctx = lbl_status.get_style_context()
        ctx.remove_class("st-ok")
        ctx.remove_class("st-wait")
        ctx.remove_class("st-lock")
        if is_locked:
            lbl_status.set_text("🔒 ĐANG TẠM KHÓA BỞI GIÁO VIÊN")
            ctx.add_class("st-lock")
        elif connected:
            lbl_status.set_text(f"✅ ĐÃ KẾT NỐI GIÁO VIÊN ({host})")
            ctx.add_class("st-ok")
        else:
            lbl_status.set_text("🔄 Đang tìm máy Giáo viên qua mạng LAN...")
            ctx.add_class("st-wait")

        btn_hand.set_label("✋ ĐÃ GIƠ TAY" if os.path.exists(HAND_FLAG) else "✋ Giơ tay")
        return True

    tick()
    GLib.timeout_add(1000, tick)
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()


def run_tk_bar():
    import tkinter as tk
    from tkinter import messagebox

    root = tk.Tk()
    root.title("NetLaps Student v2.7.0")
    root.attributes("-topmost", True)
    root.configure(bg="#0F172A")
    root.resizable(False, False)
    screen_w = root.winfo_screenwidth()
    bar_w, bar_h = 680, 56
    root.geometry(f"{bar_w}x{bar_h}+{max(10, int((screen_w - bar_w) / 2))}+12")

    main_frame = tk.Frame(root, bg="#0F172A", bd=1, relief="ridge")
    main_frame.pack(fill="both", expand=True)

    f_left = tk.Frame(main_frame, bg="#0F172A")
    f_left.pack(side="left", padx=(12, 8), pady=8)
    tk.Label(f_left, text="🛡️ NetLaps", font=("DejaVu Sans", 11, "bold"), fg="#38BDF8", bg="#0F172A").pack(side="left")
    tk.Label(f_left, text="v2.7.0", font=("DejaVu Sans", 8, "bold"), fg="#64748B", bg="#1E293B", padx=4, pady=1).pack(side="left", padx=5)

    f_mid = tk.Frame(main_frame, bg="#0F172A")
    f_mid.pack(side="left", padx=10, pady=8)
    lbl_seat = tk.Label(f_mid, text="Máy: ... | Phòng: ...", font=("DejaVu Sans", 10, "bold"), fg="#F8FAFC", bg="#0F172A")
    lbl_seat.pack(anchor="w")
    lbl_status = tk.Label(f_mid, text="🔄 Đang dò tìm máy Giáo viên...", font=("DejaVu Sans", 9), fg="#94A3B8", bg="#0F172A")
    lbl_status.pack(anchor="w")

    f_right = tk.Frame(main_frame, bg="#0F172A")
    f_right.pack(side="right", padx=(8, 12), pady=8)

    def toggle_hand():
        if os.path.exists(HAND_FLAG):
            try:
                os.remove(HAND_FLAG)
            except Exception:
                pass
        else:
            try:
                with open(HAND_FLAG, "w", encoding="utf-8") as f:
                    f.write("hand")
            except Exception:
                pass

    btn_hand = tk.Button(f_right, text="✋ Giơ tay", font=("DejaVu Sans", 9, "bold"), bg="#334155", fg="#F8FAFC", bd=0, padx=10, pady=4, command=toggle_hand)
    btn_hand.pack(side="left", padx=4)
    tk.Button(f_right, text="⚙️ Kết nối", font=("DejaVu Sans", 9), bg="#1E293B", fg="#CBD5E1", bd=0, padx=8, pady=4, command=open_setup_wizard).pack(side="left", padx=4)

    last_spawn = [0.0]

    def update_status():
        seat, room, connected, host, is_locked = read_status_and_ensure_daemon(last_spawn)
        lbl_seat.config(text=f"Bàn máy: {seat}  •  Phòng: [{room}]")
        if is_locked:
            lbl_status.config(text="🔒 ĐANG TẠM KHÓA BỞI GIÁO VIÊN", fg="#EF4444")
        elif connected:
            lbl_status.config(text=f"✅ ĐÃ KẾT NỐI GIÁO VIÊN ({host})", fg="#10B981")
        else:
            lbl_status.config(text="🔄 Đang tìm máy Giáo viên qua mạng LAN...", fg="#F59E0B")
        if os.path.exists(HAND_FLAG):
            btn_hand.configure(bg="#F59E0B", fg="#000000", text="✋ ĐÃ GIƠ TAY")
        else:
            btn_hand.configure(bg="#334155", fg="#F8FAFC", text="✋ Giơ tay")
        root.after(1000, update_status)

    update_status()
    root.mainloop()


if __name__ == "__main__":
    try:
        run_gtk_bar()
    except Exception:
        run_tk_bar()
