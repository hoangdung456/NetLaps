#!/usr/bin/env bash
# ==============================================================================
# NetLaps Student - Ubuntu Display Session Wrapper v2.5.6
# Auto-detects active graphical session (X11 / Wayland) and logged-in user
# ==============================================================================

if [ -z "$DISPLAY" ]; then
    for sock in /tmp/.X11-unix/X*; do
        if [ -S "$sock" ]; then
            DISP_NUM=$(basename "$sock" | sed 's/X//')
            export DISPLAY=":${DISP_NUM}"
            break
        fi
    done
fi
export DISPLAY="${DISPLAY:-:0}"

if [ -z "$XAUTHORITY" ]; then
    for auth in /run/user/*/gdm/Xauthority /run/user/*/.Xauthority /home/*/.Xauthority; do
        if [ -f "$auth" ]; then
            export XAUTHORITY="$auth"
            break
        fi
    done
fi

# 1. Start background student agent daemon if not running
if ! pgrep -f "/opt/netlaps-student/netlaps-student" >/dev/null 2>&1; then
    /opt/netlaps-student/netlaps-student "$@" >/dev/null 2>&1 &
    sleep 0.8
fi

# 2. Launch Desktop Widget Toolbar if GUI is present and toolbar not already running
if [ -n "$DISPLAY" ] && command -v python3 >/dev/null 2>&1; then
    if [ -f "/opt/netlaps-student/netlaps-student-bar.py" ]; then
        if ! pgrep -f "netlaps-student-bar.py" >/dev/null 2>&1; then
            exec python3 /opt/netlaps-student/netlaps-student-bar.py
        fi
    fi
fi
