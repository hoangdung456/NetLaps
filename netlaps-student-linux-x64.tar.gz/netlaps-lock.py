#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Student Linux - Fullscreen Remote Lock Screen Overlay v2.7.0
Hỗ trợ tự động cả GTK3 (có sẵn 100% trên mọi máy Ubuntu Desktop) và Tkinter!
"""

import sys
import os
import signal
import time

UNLOCK_FILES = ["/etc/netlaps/unlock.flag", "/tmp/netlaps_unlock.flag"]


def is_unlock_requested():
    for p in UNLOCK_FILES:
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass
            return True
    return False


def clear_unlock_flags():
    for p in UNLOCK_FILES:
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass


def run_gtk_lock(message):
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, Gdk, GLib

    win = Gtk.Window(title="NetLaps Lock Screen")
    win.set_decorated(False)
    win.set_keep_above(True)
    win.fullscreen()

    css = b"""
    window { background-color: #0B132B; color: #FFFFFF; }
    .badge-lbl { color: #38BDF8; font-weight: bold; font-size: 16px; }
    .icon-lbl { color: #FFD166; font-size: 72px; }
    .title-lbl { color: #FFFFFF; font-weight: bold; font-size: 32px; }
    .msg-lbl { color: #E2E8F0; font-size: 18px; }
    .clock-lbl { color: #38BDF8; font-weight: bold; font-size: 20px; }
    .footer-lbl { color: #94A3B8; font-style: italic; font-size: 13px; }
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(),
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

    vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
    vbox.set_valign(Gtk.Align.CENTER)
    vbox.set_halign(Gtk.Align.CENTER)
    vbox.set_margin_top(60)
    vbox.set_margin_bottom(60)
    vbox.set_margin_start(60)
    vbox.set_margin_end(60)
    win.add(vbox)

    lbl_badge = Gtk.Label(label="🛡️ NETLAPS COMMERCIAL v2.7.0 — PHÒNG MÁY TRƯỜNG HỌC")
    lbl_badge.get_style_context().add_class("badge-lbl")
    vbox.pack_start(lbl_badge, False, False, 0)

    lbl_icon = Gtk.Label(label="🔒")
    lbl_icon.get_style_context().add_class("icon-lbl")
    vbox.pack_start(lbl_icon, False, False, 10)

    lbl_title = Gtk.Label(label="CHÚ Ý LẮNG NGHE BÀI GIẢNG!")
    lbl_title.get_style_context().add_class("title-lbl")
    vbox.pack_start(lbl_title, False, False, 6)

    display_msg = message if message else "Máy tính của bạn đang được tạm khóa bởi Giáo viên.\nVui lòng chú ý hướng dẫn trên màn hình chính của lớp học!"
    lbl_msg = Gtk.Label(label=display_msg)
    lbl_msg.set_line_wrap(True)
    lbl_msg.set_justify(Gtk.Justification.CENTER)
    lbl_msg.get_style_context().add_class("msg-lbl")
    vbox.pack_start(lbl_msg, False, False, 12)

    lbl_clock = Gtk.Label(label="")
    lbl_clock.get_style_context().add_class("clock-lbl")
    vbox.pack_start(lbl_clock, False, False, 10)

    lbl_footer = Gtk.Label(label="Máy tính sẽ tự động mở lại ngay khi Giáo viên kết thúc phần hướng dẫn.")
    lbl_footer.get_style_context().add_class("footer-lbl")
    vbox.pack_start(lbl_footer, False, False, 20)

    win.connect("delete-event", lambda *_: True)

    def tick():
        if is_unlock_requested():
            Gtk.main_quit()
            return False
        current_time = time.strftime("%H:%M:%S  •  %d/%m/%Y")
        lbl_clock.set_text(f"🕒 {current_time}")
        win.present()
        win.fullscreen()
        win.set_keep_above(True)
        return True

    tick()
    GLib.timeout_add(300, tick)
    win.show_all()
    Gtk.main()


def run_tk_lock(message):
    import tkinter as tk

    root = tk.Tk()
    root.title("NetLaps Lock Screen")
    root.attributes("-fullscreen", True)
    root.attributes("-topmost", True)
    root.configure(bg="#0B132B")
    root.config(cursor="none")

    root.protocol("WM_DELETE_WINDOW", lambda: None)
    root.bind("<Alt-F4>", lambda e: "break")
    root.bind("<Escape>", lambda e: "break")

    container = tk.Frame(root, bg="#0B132B")
    container.pack(expand=True, fill="both", padx=60, pady=60)

    tk.Label(container, text="🛡️ NETLAPS COMMERCIAL v2.7.0 — PHÒNG MÁY TRƯỜNG HỌC", font=("DejaVu Sans", 13, "bold"), fg="#64DFDF", bg="#0B132B").pack(pady=(20, 10))
    tk.Label(container, text="🔒", font=("DejaVu Sans", 72), fg="#FFD166", bg="#0B132B").pack(pady=(10, 15))
    tk.Label(container, text="CHÚ Ý LẮNG NGHE BÀI GIẢNG!", font=("DejaVu Sans", 28, "bold"), fg="#FFFFFF", bg="#0B132B").pack(pady=(5, 15))

    display_msg = message if message else "Máy tính của bạn đang được tạm khóa bởi Giáo viên.\nVui lòng chú ý hướng dẫn trên màn hình chính của lớp học!"
    tk.Label(container, text=display_msg, font=("DejaVu Sans", 16), fg="#E0E1DD", bg="#0B132B", wraplength=800, justify="center").pack(pady=(10, 30))

    lbl_clock = tk.Label(container, text="", font=("DejaVu Sans", 18, "bold"), fg="#48CAE4", bg="#0B132B")
    lbl_clock.pack(pady=(10, 10))

    def check_loop():
        if is_unlock_requested():
            root.destroy()
            return
        lbl_clock.config(text=f"🕒 {time.strftime('%H:%M:%S  •  %d/%m/%Y')}")
        root.after(300, check_loop)

    check_loop()
    root.mainloop()


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    signal.signal(signal.SIGINT, lambda *_: sys.exit(0))
    clear_unlock_flags()
    msg = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else ""
    try:
        run_gtk_lock(msg)
    except Exception:
        try:
            run_tk_lock(msg)
        except Exception:
            pass
