#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NetLaps Student Linux - Fullscreen Remote Lock Screen Overlay
Runs on Ubuntu (X11 / GNOME / MATE / XFCE) to keep students focused during teacher lectures.
"""

import sys
import os
import signal
import time

try:
    import tkinter as tk
    from tkinter import font
except ImportError:
    # Fallback to zenity or basic xmessage if tkinter is absent
    msg = sys.argv[1] if len(sys.argv) > 1 else "CHÚ Ý LẮNG NGHE BÀI GIẢNG! Máy tính đang tạm khóa bởi Giáo viên."
    os.system(f"zenity --warning --text='{msg}' --title='NetLaps Khóa Màn Hình' --width=500 2>/dev/null &")
    sys.exit(0)

class NetLapsLockWindow:
    def __init__(self, root, message):
        self.root = root
        self.root.title("NetLaps Lock Screen")
        self.root.attributes("-fullscreen", True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg="#0B132B")
        self.root.config(cursor="none") # Hide mouse cursor while locked

        # Prevent closing via Alt+F4 or window manager
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)
        self.root.bind("<Alt-F4>", lambda e: "break")
        self.root.bind("<Alt-Tab>", lambda e: "break")
        self.root.bind("<Escape>", lambda e: "break")
        self.root.bind("<Control-c>", lambda e: "break")
        self.root.bind("<Super_L>", lambda e: "break")

        # Container
        container = tk.Frame(root, bg="#0B132B")
        container.pack(expand=True, fill="both", padx=60, pady=60)

        # Top Badge
        lbl_badge = tk.Label(
            container,
            text="🛡️ NETLAPS COMMERCIAL v2.5.6 — PHÒNG MÁY TRƯỜNG HỌC",
            font=("DejaVu Sans", 13, "bold"),
            fg="#64DFDF",
            bg="#0B132B"
        )
        lbl_badge.pack(pady=(20, 10))

        # Big Lock Icon
        lbl_icon = tk.Label(
            container,
            text="🔒",
            font=("DejaVu Sans", 72),
            fg="#FFD166",
            bg="#0B132B"
        )
        lbl_icon.pack(pady=(10, 15))

        # Main Title
        lbl_title = tk.Label(
            container,
            text="CHÚ Ý LẮNG NGHE BÀI GIẢNG!",
            font=("DejaVu Sans", 28, "bold"),
            fg="#FFFFFF",
            bg="#0B132B"
        )
        lbl_title.pack(pady=(5, 15))

        # Teacher's custom message
        display_msg = message if message else "Máy tính của bạn đang được tạm khóa bởi Giáo viên.\nVui lòng chú ý hướng dẫn trên màn hình chính của lớp học!"
        lbl_msg = tk.Label(
            container,
            text=display_msg,
            font=("DejaVu Sans", 16),
            fg="#E0E1DD",
            bg="#0B132B",
            wraplength=800,
            justify="center"
        )
        lbl_msg.pack(pady=(10, 30))

        # Live Clock
        self.lbl_clock = tk.Label(
            container,
            text="",
            font=("DejaVu Sans", 18, "bold"),
            fg="#48CAE4",
            bg="#0B132B"
        )
        self.lbl_clock.pack(pady=(10, 10))
        self.update_clock()

        # Footer
        lbl_footer = tk.Label(
            container,
            text="Máy tính sẽ tự động mở lại ngay khi Giáo viên kết thúc phần hướng dẫn.",
            font=("DejaVu Sans", 11, "italic"),
            fg="#778DA9",
            bg="#0B132B"
        )
        lbl_footer.pack(side="bottom", pady=20)

        # Check for unlock flag file every 300ms
        self.check_unlock_flag()

    def update_clock(self):
        current_time = time.strftime("%H:%M:%S  •  %d/%m/%Y")
        self.lbl_clock.config(text=f"🕒 {current_time}")
        self.root.after(1000, self.update_clock)

    def check_unlock_flag(self):
        if os.path.exists("/tmp/netlaps_unlock.flag"):
            try:
                os.remove("/tmp/netlaps_unlock.flag")
            except:
                pass
            self.root.destroy()
            return
        self.root.after(300, self.check_unlock_flag)

def handle_sigterm(signum, frame):
    sys.exit(0)

if __name__ == "__main__":
    signal.signal(signal.SIGTERM, handle_sigterm)
    signal.signal(signal.SIGINT, handle_sigterm)

    # Clean previous unlock flag
    if os.path.exists("/tmp/netlaps_unlock.flag"):
        try: os.remove("/tmp/netlaps_unlock.flag")
        except: pass

    msg = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else ""
    root = tk.Tk()
    app = NetLapsLockWindow(root, msg)
    root.mainloop()
