#!/usr/bin/env bash
# ==============================================================================
# NETLAPS STUDENT FOR UBUNTU LINUX — UNIVERSAL INSTALLER v2.5
# Hỗ trợ: Ubuntu 20.04 / 22.04 / 24.04 LTS (x86_64 / amd64)
# Hotline / Zalo: 0385545556 | Facebook: fb.com/HdMarketing98
# ==============================================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   🐧 ĐANG CÀI ĐẶT NETLAPS STUDENT TRÊN HỆ ĐIỀU HÀNH UBUNTU LINUX...          ${NC}"
echo -e "${BLUE}==============================================================================${NC}"

# 1. Check Root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[LỖI] Vui lòng chạy trình cài đặt với quyền quản trị viên: sudo bash install.sh${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/netlaps-student"
CONFIG_DIR="/etc/netlaps"

echo -e "${YELLOW}[1/5] Kiểm tra và cập nhật các gói phụ trợ màn hình (python3-tk, scrot, xdotool)...${NC}"
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -qq || true
  apt-get install -y -qq python3 python3-tk scrot xdotool libssl-dev 2>/dev/null || true
fi

echo -e "${YELLOW}[2/5] Sao chép tệp chương trình vào ${INSTALL_DIR}...${NC}"
mkdir -p "${INSTALL_DIR}"
mkdir -p "${CONFIG_DIR}"

cp -f "${SCRIPT_DIR}/netlaps-student" "${INSTALL_DIR}/netlaps-student"
cp -f "${SCRIPT_DIR}/netlaps-student-run.sh" "${INSTALL_DIR}/netlaps-student-run.sh" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps-student-bar.py" "${INSTALL_DIR}/netlaps-student-bar.py" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps-lock.py" "${INSTALL_DIR}/netlaps-lock.py" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps-broadcast.py" "${INSTALL_DIR}/netlaps-broadcast.py" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_student.png" "${INSTALL_DIR}/netlaps_student.png" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps-student.desktop" "${INSTALL_DIR}/netlaps-student.desktop" 2>/dev/null || true

# Generate default configuration if not exists
if [ ! -f "${CONFIG_DIR}/student.json" ]; then
  HOSTNAME=$(hostname)
  cat > "${CONFIG_DIR}/student.json" <<EOF
{
  "RoomId": "LAB-01",
  "RoomSecret": "NetClass2026",
  "SeatCode": "UBU-${HOSTNAME}",
  "StudentName": "",
  "TeacherHost": "",
  "TeacherPort": 5055,
  "AutoDiscover": true,
  "ThumbnailFps": 2,
  "EnableLockOverlay": true
}
EOF
fi

echo -e "${YELLOW}[3/5] Cấp quyền thực thi hệ thống (chmod +x)...${NC}"
chmod 755 "${INSTALL_DIR}/netlaps-student"
chmod 755 "${INSTALL_DIR}"/*.py 2>/dev/null || true

echo -e "${YELLOW}[4/5] Cài đặt Dịch vụ nền (Systemd Service) & Tự khởi động khi học sinh đăng nhập...${NC}"
# Install systemd service
if [ -f "${SCRIPT_DIR}/netlaps-student.service" ]; then
  cp -f "${SCRIPT_DIR}/netlaps-student.service" /etc/systemd/system/netlaps-student.service
  chmod 644 /etc/systemd/system/netlaps-student.service
  systemctl daemon-reload
  systemctl enable netlaps-student.service
fi

# Install Desktop Shortcut & XDG Autostart
if [ -f "${SCRIPT_DIR}/netlaps-student.desktop" ]; then
  mkdir -p /usr/share/applications
  mkdir -p /etc/xdg/autostart
  cp -f "${SCRIPT_DIR}/netlaps-student.desktop" /usr/share/applications/netlaps-student.desktop
  cp -f "${SCRIPT_DIR}/netlaps-student.desktop" /etc/xdg/autostart/netlaps-student.desktop
  chmod 644 /usr/share/applications/netlaps-student.desktop
  chmod 644 /etc/xdg/autostart/netlaps-student.desktop

  # Place desktop icon on desktop of all active human users
  for user_home in /home/*; do
    if [ -d "${user_home}/Desktop" ]; then
      cp -f "${SCRIPT_DIR}/netlaps-student.desktop" "${user_home}/Desktop/netlaps-student.desktop"
      chmod +x "${user_home}/Desktop/netlaps-student.desktop"
      user_name=$(basename "${user_home}")
      chown "${user_name}:${user_name}" "${user_home}/Desktop/netlaps-student.desktop" 2>/dev/null || true
      su - "${user_name}" -c "gio set '${user_home}/Desktop/netlaps-student.desktop' metadata::trusted true" 2>/dev/null || true
    fi
  done
fi

echo -e "${YELLOW}[5/5] Khởi động NetLaps Student ngay bây giờ...${NC}"
systemctl restart netlaps-student.service || true

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   ✅ CÀI ĐẶT THÀNH CÔNG NETLAPS STUDENT TRÊN MÁY UBUNTU LINUX NÀY!           ${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo -e "💻 Tên máy học sinh:  $(hostname) (Vị trí: UBU-$(hostname))"
echo -e "📁 Thư mục cài đặt:   ${INSTALL_DIR}"
echo -e "⚙️ Tệp cấu hình:       ${CONFIG_DIR}/student.json"
echo -e "🔄 Trạng thái:        Đang chạy tự động ở chế độ dịch vụ nền (systemd)"
echo -e "                      Mở máy Giáo viên lên để thấy máy Ubuntu xuất hiện ngay!"
echo -e ""
echo -e "Lệnh hữu ích:"
echo -e "  - Kiểm tra trạng thái:  sudo systemctl status netlaps-student"
echo -e "  - Xem nhật ký kết nối:  sudo journalctl -u netlaps-student -f"
echo -e "  - Khởi động lại:        sudo systemctl restart netlaps-student"
echo -e "  - Gỡ cài đặt:           sudo bash uninstall.sh"
echo -e "${BLUE}==============================================================================${NC}"
