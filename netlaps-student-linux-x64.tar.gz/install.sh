#!/usr/bin/env bash
# ==============================================================================
# NETLAPS STUDENT FOR UBUNTU LINUX — UNIVERSAL INSTALLER v2.7.0
# Hỗ trợ: Ubuntu 20.04 / 22.04 / 24.04 LTS (x86_64 / amd64)
# Hotline / Zalo: 0385545556 | Facebook: fb.com/HdMarketing98
# ==============================================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   🐧 ĐANG CÀI ĐẶT NETLAPS STUDENT (MÁY HỌC SINH) UBUNTU v2.7.0...            ${NC}"
echo -e "${BLUE}==============================================================================${NC}"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[LỖI] Vui lòng chạy với quyền quản trị viên: sudo bash install.sh${NC}"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/netlaps-student"
CONFIG_DIR="/etc/netlaps"

# Cài đặt phụ thuộc cần thiết cho màn hình khóa, âm thanh, biểu tượng
if command -v apt-get >/dev/null 2>&1; then
  echo -e "${YELLOW}[0/5] Kiểm tra thư viện hỗ trợ (python3-tk, x11-utils, libnotify-bin, alsa-utils)...${NC}"
  apt-get update -qq 2>/dev/null || true
  apt-get install -y -qq python3-tk x11-utils xdotool libnotify-bin alsa-utils pulseaudio-utils 2>/dev/null || true
fi

echo -e "${YELLOW}[1/5] Sao chép tệp chương trình vào ${INSTALL_DIR}...${NC}"
mkdir -p "${INSTALL_DIR}"
cp -f "${SCRIPT_DIR}/netlaps-student" "${INSTALL_DIR}/netlaps-student"
cp -f "${SCRIPT_DIR}/netlaps-student-run.sh" "${INSTALL_DIR}/netlaps-student-run.sh" 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_student.png" "${INSTALL_DIR}/netlaps_student.png" 2>/dev/null || true
cp -f "${SCRIPT_DIR}"/*.py "${INSTALL_DIR}/" 2>/dev/null || true
cp -f "${SCRIPT_DIR}"/*.desktop "${INSTALL_DIR}/" 2>/dev/null || true

chmod 755 "${INSTALL_DIR}/netlaps-student"
chmod 755 "${INSTALL_DIR}/netlaps-student-run.sh" 2>/dev/null || true
chmod 755 "${INSTALL_DIR}"/*.py 2>/dev/null || true
ln -sf "${INSTALL_DIR}/netlaps-student" /usr/bin/netlaps-student 2>/dev/null || true
ln -sf "${INSTALL_DIR}/netlaps-student-run.sh" /usr/bin/netlaps-student-gui 2>/dev/null || true
ln -sf "${INSTALL_DIR}/netlaps-student-config-gui.py" /usr/bin/netlaps-student-setup 2>/dev/null || true

# Mở cổng tường lửa Ubuntu (ufw)
if command -v ufw >/dev/null 2>&1; then
  ufw allow 5055/tcp 2>/dev/null || true
  ufw allow 5056/udp 2>/dev/null || true
fi

# Cài đặt Icon
mkdir -p /usr/share/pixmaps
mkdir -p /usr/share/icons/hicolor/128x128/apps
cp -f "${SCRIPT_DIR}/netlaps_student.png" /usr/share/pixmaps/netlaps_student.png 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_student.png" /usr/share/pixmaps/netlaps-student.png 2>/dev/null || true
cp -f "${SCRIPT_DIR}/netlaps_student.png" /usr/share/icons/hicolor/128x128/apps/netlaps-student.png 2>/dev/null || true
gtk-update-icon-cache /usr/share/icons/hicolor 2>/dev/null || true

echo -e "${YELLOW}[2/5] Khởi tạo tệp cấu hình tại ${CONFIG_DIR}/student.json...${NC}"
mkdir -p "${CONFIG_DIR}"
chmod 777 "${CONFIG_DIR}" 2>/dev/null || true
TEACHER_ARG=""
ROOM_ARG="LAB-01"
while [[ $# -gt 0 ]]; do
  case $1 in
    --teacher|-t) TEACHER_ARG="$2"; shift 2 ;;
    --room|-r) ROOM_ARG="$2"; shift 2 ;;
    *) shift ;;
  esac
done

if [ ! -f "${CONFIG_DIR}/student.json" ] || [ -n "${TEACHER_ARG}" ]; then
  cat > "${CONFIG_DIR}/student.json" <<EOF
{
  "RoomId": "${ROOM_ARG}",
  "RoomSecret": "NetClass2026",
  "SeatCode": "MAY-$(hostname)",
  "StudentName": "",
  "TeacherHost": "${TEACHER_ARG}",
  "TeacherPort": 5055,
  "AutoDiscover": true,
  "ThumbnailFps": 2,
  "EnableLockOverlay": true
}
EOF
fi
chmod 666 "${CONFIG_DIR}/student.json" 2>/dev/null || true
touch "${CONFIG_DIR}/status.json" 2>/dev/null || true
chmod 666 "${CONFIG_DIR}/status.json" 2>/dev/null || true

echo -e "${YELLOW}[3/5] Cài đặt Dịch vụ nền (Systemd Service)...${NC}"
if [ -f "${SCRIPT_DIR}/netlaps-student.service" ]; then
  cp -f "${SCRIPT_DIR}/netlaps-student.service" /etc/systemd/system/netlaps-student.service
  chmod 644 /etc/systemd/system/netlaps-student.service
  systemctl daemon-reload
  systemctl enable netlaps-student.service
  systemctl restart netlaps-student.service 2>/dev/null || true
fi

echo -e "${YELLOW}[4/5] Cài đặt Tự khởi động (Autostart) & Biểu tượng Desktop...${NC}"
mkdir -p /usr/share/applications
mkdir -p /etc/xdg/autostart

for desk_file in "${SCRIPT_DIR}/netlaps-student.desktop" "${SCRIPT_DIR}/netlaps-student-config.desktop"; do
  if [ -f "$desk_file" ]; then
    fname=$(basename "$desk_file")
    cp -f "$desk_file" "/usr/share/applications/$fname"
    chmod 644 "/usr/share/applications/$fname"

    if [ "$fname" = "netlaps-student.desktop" ]; then
      cp -f "$desk_file" "/etc/xdg/autostart/$fname"
      chmod 644 "/etc/xdg/autostart/$fname"
    fi

    for user_home in /home/*; do
      user_name=$(basename "${user_home}")
      for desk_dir in "${user_home}/Desktop" "${user_home}/Màn hình nền"; do
        if [ -d "$desk_dir" ]; then
          cp -f "$desk_file" "$desk_dir/$fname"
          chmod +x "$desk_dir/$fname"
          chown "${user_name}:${user_name}" "$desk_dir/$fname" 2>/dev/null || true
          su - "${user_name}" -c "gio set '$desk_dir/$fname' metadata::trusted true" 2>/dev/null || true
          su - "${user_name}" -c "gio set '$desk_dir/$fname' metadata::trusted yes" 2>/dev/null || true
        fi
      done
    done
  fi
done

echo -e "${YELLOW}[5/5] Khởi động Dịch vụ NetLaps Student...${NC}"
systemctl restart netlaps-student.service || true

echo -e "${BLUE}==============================================================================${NC}"
echo -e "${GREEN}   ✅ CÀI ĐẶT THÀNH CÔNG NETLAPS STUDENT v2.7.0 TRÊN UBUNTU LINUX!            ${NC}"
echo -e "${BLUE}==============================================================================${NC}"
echo -e "💡 HƯỚNG DẪN CẤU HÌNH:"
echo -e "   1. Bấm vào biểu tượng 'Thiết Lập NetLaps Student' trên Desktop để mở cửa sổ cài đặt."
echo -e "   2. Hoặc gõ lệnh trong Terminal: netlaps-student-setup"
echo -e "   3. Cửa sổ thiết lập giống 100% bản Windows: Nhập IP Giáo viên và bấm 'Next' là xong!"
echo -e "${BLUE}==============================================================================${NC}"

# Tự động mở cửa sổ thiết lập GUI nếu đang trong phiên đồ họa
if [ -n "$DISPLAY" ] && command -v python3 >/dev/null 2>&1; then
  python3 "${INSTALL_DIR}/netlaps-student-config-gui.py" 2>/dev/null &
fi
