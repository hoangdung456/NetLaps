﻿@echo off
chcp 65001 >nul
echo Dang cap nhat NetLaps Tutor len phien ban moi nhat...
taskkill /F /IM NetLaps.Tutor.exe >nul 2>&1
timeout /t 1 /nobreak >nul
copy /Y NetClass.Core.dll "%~dp0..\NetClass.Core.dll" >nul 2>&1
copy /Y NetLaps.Tutor.dll "%~dp0..\NetLaps.Tutor.dll" >nul 2>&1
copy /Y NetLaps.Tutor.exe "%~dp0..\NetLaps.Tutor.exe" >nul 2>&1
copy /Y NetClass.Core.dll "C:\Program Files\NetLaps\Tutor\NetClass.Core.dll" >nul 2>&1
copy /Y NetLaps.Tutor.dll "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.dll" >nul 2>&1
copy /Y NetLaps.Tutor.exe "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.exe" >nul 2>&1
echo [HOAN TAT] Da cap nhat NetLaps Tutor thanh cong!
start "" "C:\Program Files\NetLaps\Tutor\NetLaps.Tutor.exe"
